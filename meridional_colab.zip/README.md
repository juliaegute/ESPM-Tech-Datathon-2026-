# Meridional · inteligência com evidências

Aplicação Python para conversar em português com os dados do desafio, comparar hoje/2027/2033, rastrear classificações e simular hipóteses explícitas. Gradio conecta a interface ao Python; não é uma página estática. A caixa de pergunta aparece antes do histórico e dos indicadores.

**Fontes atuais:** entrega v5 e `base_itens.csv` incorporadas. Os 15.000 pares `chave + nItem` coincidem integralmente entre CSV final, JSON de simulação e base de itens. Há 95 códigos de produto, 19 fornecedores, 8 destinatários de vendas e 960 compras para uso e consumo. O CSV final e o JSON da v5 têm prioridade; o consolidado anterior foi preservado. Ainda falta o ZIP original de DANFEs, cadastros e tabelas: a referência recebida foi conferida aritmeticamente, sem certificar documentos primários ou a acurácia das classificações. [Auditoria atualizada](docs/AUDITORIA_FONTES.md).

## 1. Abrir no Google Colab

1. Baixe **[Meridional_IA.ipynb](Meridional_IA.ipynb)** e **`dist/meridional_colab.zip`**. Abra o notebook no Google Colab em **Arquivo → Fazer upload de notebook**.
2. Execute a primeira célula e selecione o ZIP da aplicação. Execute a célula de instalação.
3. Para usar IA, configure o segredo do Colab **`MERIDIONAL_API_KEY`** com uma chave da API OpenAI, ou use a entrada protegida da célula. A assinatura do ChatGPT não inclui créditos da API. Não cole chaves em células, mensagens ou arquivos.
4. Execute a célula de interface. Digite uma pergunta e clique em **Enviar**. Para experimentar sem API, clique explicitamente em **Experimentar modo local · sem IA**; esse modo usa padrões limitados e informa essa condição nas respostas.
5. Faça uma continuação, como **E em 2027?**. Veja o recorte ativo. Abra **Fontes e registros** para consultar os trechos, baixar as fontes existentes e exportar todos os itens da análise.
6. Se o iframe não aparecer, execute a célula **Conversa direta no notebook**. O contexto é preservado nessa conversa, independentemente do histórico da interface.

A interface usa o proxy de porta do Colab, com `share=False`. Não cria túnel Gradio público. Ela depende da sessão ativa do notebook; pessoas com acesso à sessão e às suas saídas podem acessar os dados exibidos. A abertura nativa no Colab ainda precisa ser verificada no próprio Colab; o servidor, os callbacks e o navegador foram exercitados no ambiente de desenvolvimento. [Relatório de testes](docs/RELATORIO_TESTES.md).

## 2. Executar no computador ou no ambiente de desenvolvimento

Recomendado: Python 3.12. Não requer GPU, banco de dados ou serviço externo para os cálculos.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

O terminal informa o endereço local de acesso. O servidor escuta apenas no próprio computador (`127.0.0.1`) e não publica os dados. Na interface, configure a chave no campo protegido ou escolha o modo local. Opcionalmente injete `MERIDIONAL_API_KEY` e `MERIDIONAL_MODEL` pelo gerenciador de segredos do seu ambiente, sem salvar valores no projeto.

Para parar, use `Ctrl+C` no terminal. No Colab, execute `aplicacao.close()` ou encerre a sessão. Para reconstruir o ZIP: `python scripts/empacotar.py`.

## 3. O que é enviado à IA

**Provedor:** OpenAI. **Modelo padrão:** `gpt-4.1-mini`, configurável na interface. Integração real por HTTPS com a API Chat Completions e JSON Schema estrito, usando a biblioteca padrão do Python (`urllib`). Uma chave real e créditos na conta são necessários para chamadas reais.

O provedor recebe a pergunta, um contexto resumido da conversa, filtros, cenário e nomes de campos/ferramentas disponíveis. Não recebe o CSV integral. As fontes documentais são recuperadas localmente; os números e as citações finais são compostos localmente. Não há ferramenta de código arbitrário, SQL livre ou gravação de dados disponível ao modelo.

O modelo **interpreta a intenção e escolhe parâmetros**. O Python valida o plano, calcula com `Decimal`, recupera fontes e compõe respostas a partir de fatos existentes. Essa composição controlada restringe a explicação ao que foi verificado, sem usar conhecimento geral para completar regras tributárias. O catálogo de ferramentas define o alcance da interpretação; perguntas que exigem ferramenta ou dado ausente recebem essa limitação.

Ausência de chave, chave inválida, falta de créditos, limite temporário, modelo indisponível, conexão e leitura dos dados têm mensagens distintas. Uma falha da API não ativa automaticamente regras locais. O **modo local limitado** precisa ser escolhido e não oferece interpretação livre de qualquer pergunta. [Arquitetura](docs/ARQUITETURA.md).

## 4. Perguntas para começar

- Onde tenho o maior ganho tributário em 2033?
- Em quais classes a carga tributária aumenta em 2027?
- O resultado vem de menos impostos nas vendas ou mais créditos nas compras?
- Analise a classe 000001 em 2033. Depois: E em 2027?
- Qual ano tem o maior imposto líquido? Qual cenário tem o menor?
- O que é CBS segundo os materiais do professor?
- Saldo negativo significa prejuízo?
- Quais documentos sustentam essa conclusão?
- Qual o prazo de ressarcimento? → informação ausente, sem prazo inventado.
- Simule aumento de 10% nos preços das compras em 2033, mantendo quantidades e mix constantes.
- Compras aumentam 10%. → pede esclarecimento; não presume preço, quantidade ou mix.
- Quais fornecedores concentram o aumento dos créditos?
- Analise o fornecedor PLASVIDA em 2033. Depois: E em 2027?
- Quais produtos explicam esse ganho?
- Analise as compras para uso e consumo em 2033.
- Por que o produto DIV001 recebeu essa classificação?

Para consultar um item, informe a chave completa e o `nItem`. Por exemplo: `Explique a classificação da chave 35260524816357000100550010000237271529658852, item 1`. A justificativa recebida aparece como **fonte declarada**, não como validação de uma DANFE que não foi anexada.

## 5. Evidências, exportação e arquivos adicionais

Em **Fontes e registros** há trechos com arquivo e página/parágrafo/linha, downloads dos originais existentes e uma prévia de até 25 itens. O CSV exportado contém **todos** os registros do recorte. Em **Auditoria e limitações**, o JSON exporta contexto, auditoria, resultados e fontes. Perguntas conceituais e fora do escopo preservam a análise anterior; **Limpar filtros** remove os filtros e **Nova conversa** reinicia o histórico e o recorte.

Os originais permanecem em `data/originais/`; os manifestos SHA-256 estão em `docs/originais.sha256.json` (cinco anexos iniciais) e `docs/complementos.sha256.json` (dois novos). As exportações são cópias em pasta temporária de cada sessão. Ao abrir um CSV no Excel, importe as colunas `chave`, NCM, CFOP e códigos como **Texto** para preservar zeros e os 44 dígitos; abrir diretamente com inferência numérica pode truncar a exibição. Textos de exportação capazes de executar fórmulas são neutralizados; o original não é modificado.

A v5 e a base de itens já acompanham o pacote: não é necessário importá-las novamente. Para acrescentar o ZIP original restante sem reescrever os arquivos:

```bash
python scripts/importar_dados.py dados_originais.zip
```

Também existe uma célula de importação opcional no notebook. Não duplique arquivos já presentes; nomes homônimos ambíguos bloqueiam a seleção em vez de substituir a referência silenciosamente. Reinicie a interface após importar. O carregador procura nomes `itens_classificados.csv`, `simulacao.json` e `base_itens.csv`, verifica o esquema e relaciona **chave + nItem**. CSV final complementar tem prioridade para classificação/status/confiança/IS/fonte, JSON para simulação e base de itens para metadados. Nomes de colunas suportados estão em `meridional/data.py`; esquemas incompatíveis não são adivinhados. Cadastros separados que precisem de adaptação de esquema devem ser integrados em tarefa específica, sem corrigir a referência.

Conflitos, chaves repetidas, itens sem correspondência e cobertura divergente são auditados; operações afetadas são bloqueadas quando não há segurança para somar. O aplicativo não corrige arquivos ou classificações. Importar arquivos com nomes de v5 não certifica automaticamente a autoria/versão escolhida pela equipe.

## 6. Regras de cálculo e limites

- **Imposto líquido** = débitos das vendas − créditos das compras.
- **Ganho simulado** = líquido de hoje − líquido do cenário.
- Vendas contribuem por imposto de hoje − imposto do cenário; compras por crédito do cenário − crédito de hoje.
- Todos os grupos reconciliam com o mesmo recorte. Fornecedor não se aplica às vendas; destinatário não se aplica às compras. Grupos sem cadastro aparecem como não informados quando a dimensão existe parcialmente.
- Usa `Decimal` e `ROUND_HALF_UP`. CBS e IBS são arredondados separadamente por item antes da soma. Os valores recebidos da simulação não são substituídos pelo recálculo de auditoria.
- IS é apenas sinalizado. As regras são as premissas congeladas dos materiais anexados, não orientação tributária geral.
- Projeção disponível: alteração percentual explícita de preços em 2033, com quantidades, mix e alíquotas constantes. A ferramenta de hipótese de hoje/2027 ainda não está implementada e validada por componente. Os valores de referência dos três cenários continuam disponíveis. A base nova contém quantidade e preço unitário, mas projeções de quantidade ou mix ainda não são ferramentas implementadas. Não calcula quantidade, mix, margens, prazo de créditos ou crescimento com dados inventados.
- Ganho positivo pode ampliar saldo credor. Crédito não é lucro nem dinheiro recebido; saldo tributário negativo não comprova prejuízo operacional. Menor imposto líquido não recomenda automaticamente comprar mais.

Veja **[Auditoria das fontes](docs/AUDITORIA_FONTES.md)** para totais e divergências documentais e **[Relatório de testes](docs/RELATORIO_TESTES.md)** para verificações executadas, simuladas e não executadas.

## 7. Testes

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

O teste de navegador usa Chromium e exige o servidor local ativo. O teste real de IA é opcional e só deve ser executado com uma chave configurada pelo usuário. Nenhum teste de resposta simulada comprova a execução de um modelo real. As instruções e resultados específicos estão no relatório.
