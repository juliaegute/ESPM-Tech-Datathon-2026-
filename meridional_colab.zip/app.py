"""Inicie com python app.py. Nenhum túnel público é criado."""
import argparse
import os
from pathlib import Path
import tempfile

os.environ.setdefault("GRADIO_ANALYTICS_ENABLED", "False")
os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "meridional-mpl"))
os.environ.setdefault("XDG_CACHE_HOME", str(Path(tempfile.gettempdir()) / "meridional-cache"))


def main():
    from meridional.ui import build_app

    parser = argparse.ArgumentParser(description="Meridional · inteligência com evidências")
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).parent / "data")
    parser.add_argument("--port", type=int, default=7860)
    args = parser.parse_args()
    app = build_app(args.data_dir)
    app.queue(default_concurrency_limit=4).launch(
        server_name="127.0.0.1", server_port=args.port,
        share=False, show_api=False, show_error=False,
        enable_monitoring=False,
    )


if __name__ == "__main__":
    main()
