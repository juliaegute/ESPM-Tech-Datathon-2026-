"""Importação preserva originais e recusa caminhos perigosos."""
import hashlib
from pathlib import Path
import zipfile
import pytest

from meridional.imports import import_archive


def test_preserves_archive_and_prevents_overwrite(tmp_path):
    original = tmp_path / "v5.zip"
    with zipfile.ZipFile(original, "w") as z:
        z.writestr("entrega/base_itens.csv", "chave;nItem\n001;1\n")
    digest = hashlib.sha256(original.read_bytes()).hexdigest()
    result = import_archive(original, tmp_path / "dados")
    assert hashlib.sha256((result / "pacote_original.zip").read_bytes()).hexdigest() == digest
    assert (result / "conteudo/entrega/base_itens.csv").read_text() == "chave;nItem\n001;1\n"
    with pytest.raises(ValueError, match="já foi importado"):
        import_archive(original, tmp_path / "dados")


@pytest.mark.parametrize("name", ["../vazou.txt", "/tmp/absoluto.txt", "pasta/../../x", "C:/x", "pasta\\x"])
def test_rejects_traversal(tmp_path, name):
    original = tmp_path / "ruim.zip"
    with zipfile.ZipFile(original, "w") as z:
        z.writestr(name, "não extrair")
    with pytest.raises(ValueError, match="inseguro"):
        import_archive(original, tmp_path / "dados")
    assert not (tmp_path / "vazou.txt").exists()


def test_zip_scripts_are_only_data(tmp_path):
    original = tmp_path / "original.zip"
    with zipfile.ZipFile(original, "w") as z:
        z.writestr("validar_entrega.py", "raise SystemExit('NUNCA EXECUTAR')")
    result = import_archive(original, tmp_path / "dados")
    assert (result / "conteudo/validar_entrega.py").is_file()


def test_rejects_paths_which_normalize_to_same_file(tmp_path):
    original=tmp_path/'ambiguo.zip'
    with zipfile.ZipFile(original,'w') as z:
        z.writestr('a/base_itens.csv','primeira origem')
        z.writestr('a/./base_itens.csv','sobrescrita indevida')
    with pytest.raises(ValueError,match='duplicado'):
        import_archive(original,tmp_path/'dados')
