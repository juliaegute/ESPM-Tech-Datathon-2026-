"""Callback tests: no API calls and no claims of a browser/Colab execution."""
from pathlib import Path
import csv

import pytest

from meridional.conversation import Answer
from meridional.ui import build_app, _cleanup, _metrics, _safe_csv, _scenario_table, _source_markdown


@pytest.fixture(scope="module")
def app():
    return build_app(Path(__file__).resolve().parent.parent)


def callback(app, name):
    return next(function.fn for function in app.fns.values() if function.name == name)


@pytest.fixture
def session(app, monkeypatch):
    monkeypatch.delenv("MERIDIONAL_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    initialized = callback(app, "initialize")(None)
    state = initialized[0]
    yield state
    _cleanup(state)


def test_build_and_initial_dashboard_are_connected_to_python(app, session):
    assert session.analysis["count"] == 15000
    assert len(session.records) == session.analysis["count"]
    assert session.conversation.provider is None
    assert session.analysis["gain"] == "66076701.39"


def test_missing_key_is_technical_error_without_silent_fallback(app, session):
    result = list(callback(app, "ask")("Qual é o ganho em 2033?", session))[-1]
    assert "chave" in result[1][-1]["content"].lower()
    assert session.conversation.provider is None
    assert session.analysis["count"] == 15000
    assert result[3]["interactive"] is True


def test_explicit_local_mode_submit_and_followup_keep_filter(app, session):
    callback(app, "configure")("Modo local limitado · sem IA", "", "gpt-4.1-mini", session)
    selected_class = session.records[0]["cClassTrib"]
    callback(app, "apply_filters")("2033", "cClassTrib", "cClassTrib", selected_class, session)
    list(callback(app, "ask")("Qual o ganho neste recorte em 2033?", session))
    result = list(callback(app, "ask")("E em 2027?", session))[-1]
    assert session.conversation.context["scenario"] == "2027"
    assert session.conversation.context["filters"] == {"cClassTrib": selected_class}
    assert "2027" in result[4]
    assert len(result[1]) == 4
    assert "Modo local limitado" in result[1][-1]["content"]


def test_generator_disables_input_and_rejects_duplicate_submission(app, session, monkeypatch):
    calls = []
    def fake_ask(question):
        calls.append(question)
        return Answer(text="Resposta simulada do modelo para testar a interface.")
    monkeypatch.setattr(session.conversation, "ask", fake_ask)
    first = callback(app, "ask")("Pergunta original", session)
    busy_result = next(first)
    assert busy_result[2]["interactive"] is False
    assert busy_result[3]["interactive"] is False
    duplicate = list(callback(app, "ask")("Pergunta duplicada", session))
    assert len(duplicate) == 1
    finished = next(first)
    assert calls == ["Pergunta original"]
    assert finished[3]["interactive"] is True
    assert len(session.messages) == 2


def test_sessions_and_histories_are_independent(app, session):
    other = callback(app, "initialize")(None)[0]
    try:
        callback(app, "configure")("Modo local limitado · sem IA", "", "gpt-4.1-mini", session)
        list(callback(app, "ask")("Compare os cenários", session))
        assert session.messages and other.messages == []
        assert other.conversation.provider is None
        assert session.directory != other.directory
        callback(app, "reset")(session)
        assert session.messages == []
        assert other.messages == []
    finally:
        _cleanup(other)


def test_exports_contain_full_selection_and_audit_no_secret(app, session):
    result = callback(app, "initialize")(session)
    csv_path, audit_path = Path(result[10]), Path(result[11])
    with csv_path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter=";"))
    assert len(rows) == 15000
    assert rows[0]["chave"] == session.records[0]["chave"]
    assert rows[0]["nItem"] == session.records[0]["nItem"]
    assert "auditoria" in audit_path.read_text(encoding="utf-8")
    assert "api_key" not in audit_path.read_text(encoding="utf-8")
    assert csv_path.parent == Path(session.directory)
    assert result[16] and all(Path(path).is_file() for path in result[16])


def test_csv_formula_neutralization_preserves_numerical_negatives():
    assert _safe_csv("=1+1").startswith("'")
    assert _safe_csv(" +SUM(A1:A2)").startswith("'")
    assert _safe_csv("@cmd").startswith("'")
    assert _safe_csv("-51.23") == "-51.23"
    assert _safe_csv("000123") == "000123"


def test_sources_support_engine_and_document_locations():
    result = _source_markdown([{"source": "base.csv", "first_line": "2", "claim": "Todos os registros calculados."},
                               {"source": "regras.pdf", "section": "página 5", "claim": "Definição documentada."}])
    assert "a partir da linha 2" in result
    assert "Todos os registros calculados." in result
    assert "página 5" in result


def test_hypothesis_is_separate_from_reference_in_metrics_and_table(session):
    scenario = session.analysis
    hypothetical = {"hypothetical": scenario, "reference": scenario,
                    "assumptions": {"changed_parameter": "Preços das compras +10%", "constants": "Mix constante"},
                    "reduction_vs_reference": "100.00"}
    assert "HIPÓTESE DO USUÁRIO" in _metrics(hypothetical)
    labels = [row[0] for row in _scenario_table(hypothetical)["data"]]
    assert len(labels) == 6
    assert any("Referência" in label for label in labels)
    assert any("Hipótese" in label for label in labels)


def test_colab_explicit_local_option_is_honored_without_api(monkeypatch):
    monkeypatch.delenv('MERIDIONAL_API_KEY',raising=False)
    monkeypatch.delenv('OPENAI_API_KEY',raising=False)
    app=build_app(Path(__file__).resolve().parent.parent,default_local=True)
    state=callback(app,'initialize')(None)[0]
    try:
        assert state.conversation.provider.uses_ai is False
        assert 'Modo local limitado' in state.mode
    finally:
        _cleanup(state)
