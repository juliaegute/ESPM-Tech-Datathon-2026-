"""Executed deterministic tests; fixtures never replace the uploaded originals."""
import csv
import json
import tempfile
import unittest
import shutil
from copy import deepcopy
from decimal import Decimal
from pathlib import Path

from meridional.data import DataError, DataStore, money
from meridional.engine import Engine

ROOT = Path(__file__).resolve().parents[1]


def item(index=1, perspective="compra", **kwargs):
    result = {"chave": "0" * 43 + str(index), "nItem": "1", "cClassTrib": "000001", "cClassTrib_simulacao": "000001", "status": "CLASSIFICADO", "confianca": "0.90", "imposto_seletivo": "nao", "fonte": "cadastro_inexistente.csv:linha 2", "perspectiva": perspective, "vProd": "100.00", "hoje_imposto": "10.00", "hoje_credito": "10.00" if perspective == "compra" else "", "2027_imposto": "18.80", "2027_credito": "18.80" if perspective == "compra" else "", "2033_imposto": "26.50", "2033_credito": "26.50" if perspective == "compra" else ""}
    result.update(kwargs)
    return result


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fields, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)


def simulation(rows):
    items = []
    for row in rows:
        val = {k: row[k] for k in ("chave", "nItem", "cClassTrib", "perspectiva", "vProd")}
        for scenario in ("hoje", "2027", "2033"):
            val[scenario] = {"imposto": row[f"{scenario}_imposto"], "credito": row[f"{scenario}_credito"] or None}
        items.append(val)
    return {"itens": items}


class UploadedDataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.store = DataStore(ROOT)
        cls.engine = Engine(cls.store)

    def test_full_totals_against_independent_decimal_sums(self):
        actual = self.engine.analyze()
        expected = {"hoje": ("524204.08", "2055856.72", "-1531652.64"), "2027": ("540295.24", "24242989.24", "-23702694.00"), "2033": ("354164.39", "67962518.42", "-67608354.03")}
        for scenario, values in expected.items():
            self.assertEqual(tuple(actual["totals"][scenario][k] for k in ("debitos", "creditos", "liquido")), values)
        self.assertEqual(actual["gain"], "66076701.39")
        self.assertEqual(actual["sales_effect"], "170039.69")
        self.assertEqual(actual["purchase_effect"], "65906661.70")

    def test_gain_and_losses_and_complete_rankings_reconcile(self):
        for scenario in ("hoje", "2027", "2033"):
            for dimension in self.store.fields:
                report = self.engine.analyze(scenario, group_by=dimension)
                self.assertEqual(sum(Decimal(g["gain"]) for g in report["ranking"]), Decimal(report["gain"]))
                self.assertEqual(sum(g["count"] for g in report["ranking"]), 15000)
        report = self.engine.analyze()
        self.assertEqual(report["ranking"][0]["label"], "000001")
        self.assertEqual(report["negative_ranking"][0]["label"], "200003")

    def test_metrics_use_credits_debits_and_full_product_values(self):
        for scenario in ("hoje", "2027", "2033"):
            for metric, total_key in (("creditos", "creditos"), ("debitos", "debitos")):
                report = self.engine.analyze(scenario, metric=metric)
                self.assertEqual(report["metric_total"], report["totals"][scenario][total_key])
                self.assertEqual(sum(Decimal(r["value"]) for r in report["metric_ranking"]), Decimal(report["metric_total"]))
        for metric, perspective in (("valor_compras", "compra"), ("valor_vendas", "venda")):
            report = self.engine.analyze(metric=metric)
            expected = sum(Decimal(r["vProd"]) for r in self.store.rows if r["perspectiva"] == perspective)
            self.assertEqual(Decimal(report["metric_total"]), expected)
            self.assertEqual(report["value_totals"][metric], report["metric_total"])

    def test_missing_supplier_and_use_consumption_not_invented(self):
        # Regression for the original, unenriched attachment. The current v5
        # dataset does have these dimensions and is tested separately.
        with tempfile.TemporaryDirectory() as directory:
            shutil.copyfile(ROOT / 'data/originais/base_completa_meridional.csv', Path(directory) / 'base_completa_meridional.csv')
            original = DataStore(directory)
            for dimension, value in (("fornecedor", "X"), ("finalidade", "uso e consumo"), ("produto", "arroz")):
                with self.assertRaises(DataError) as caught:
                    Engine(original).analyze(filters={dimension: value})
                self.assertEqual(caught.exception.code, "missing_field")
            self.assertNotIn("produto", original.fields)
        self.assertEqual(self.store.audit["corrected_in_source"], 677)

    def test_coverage_and_recalculation_are_explicit(self):
        self.assertEqual(self.store.audit["rows"], 15000)
        self.assertEqual(self.store.audit["documents"], 1387)
        self.assertEqual(self.store.audit["duplicate_keys"], 0)
        self.assertEqual(self.store.audit["recalculation_2033"]["differences"], 0)
        self.assertFalse(self.engine.analyze()["coverage"]["company_completeness_verified"])

    def test_followup_filters_possible_without_data_changes(self):
        filters = {"cClassTrib": "200003", "perspectiva": "compra"}
        first = self.engine.analyze("2033", filters)
        second = self.engine.analyze("2027", filters)
        self.assertEqual(first["filters"], second["filters"])
        self.assertEqual(first["count"], second["count"])

    def test_classification_only_reports_registered_evidence(self):
        row = self.store.rows[0]
        answer = self.engine.classification({"chave": row["chave"], "nItem": row["nItem"]})
        self.assertEqual(answer["count"], 1)
        self.assertEqual(answer["items"][0]["cClassTrib"], "000001")
        self.assertIn("declaração", answer["items"][0]["evidence_status"])
        for evidence in answer["evidence"]:
            self.assertTrue(Path(evidence["path"]).is_file())

    def test_nonexistent_record_is_not_a_zero_total(self):
        with self.assertRaises(DataError) as caught:
            self.engine.analyze(filters={"chave": "9" * 44})
        self.assertEqual(caught.exception.code, "no_matches")
        self.assertIn("não comprova", str(caught.exception))

    def test_export_contains_every_filtered_record(self):
        rows = self.engine.records({"perspectiva": "compra"})
        self.assertEqual(len(rows), 11700)
        self.assertTrue(all(r["perspectiva"] == "compra" for r in rows))

    def test_explicit_projection_separate_from_reference(self):
        reference = self.engine.analyze()
        answer = self.engine.project(percent="10", confirmed=True)
        self.assertEqual(answer["reference"]["totals"], reference["totals"])
        self.assertEqual(answer["change_in_net_tax"], "-6796252.53")
        self.assertEqual(self.engine.analyze()["totals"], reference["totals"])
        self.assertTrue(self.store.verify_originals()["ok"])

    def test_ambiguous_projection_and_missing_components_fail(self):
        with self.assertRaises(DataError):
            self.engine.project(confirmed=False)
        with self.assertRaises(DataError) as caught:
            self.engine.project(scenario="2027", confirmed=True)
        self.assertEqual(caught.exception.code, "projection_unavailable")
        with self.assertRaises(DataError):
            self.engine.project(mode="quantidade", confirmed=True)

    def test_original_files_unchanged(self):
        self.assertTrue(self.store.verify_originals()["ok"])
        manifest = json.loads((ROOT / "docs" / "originais.sha256.json").read_text())
        self.assertTrue(manifest)


class SyntheticIngestionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def load(self, rows):
        write_csv(self.root / "base_completa_meridional.csv", rows)
        return DataStore(self.root)

    def test_key_zeros_and_supplier_group_sales_do_not_disappear(self):
        store = self.load([item(fornecedor="Fornecedor A"), item(2, "venda", emitente_nome="Meridional", destinatario_nome="Cliente B")])
        self.assertEqual(store.rows[0]["chave"], "0" * 43 + "1")
        self.assertFalse(store.rows[1].get("fornecedor"))
        report = Engine(store).analyze(group_by="fornecedor")
        self.assertEqual({r["label"] for r in report["ranking"]}, {"Fornecedor A", "Não se aplica — vendas"})
        self.assertEqual(sum(Decimal(r["gain"]) for r in report["ranking"]), Decimal(report["gain"]))
        self.assertEqual(len(store.filter_rows({"fornecedor": "Fornecedor A"})), 1)

    def test_duplicates_are_preserved_and_block_totals(self):
        store = self.load([item(), item()])
        self.assertEqual(len(store.rows), 2)
        self.assertEqual(store.audit["duplicate_keys"], 1)
        with self.assertRaises(DataError):
            Engine(store).analyze()

    def test_missing_credit_does_not_mean_zero(self):
        store = self.load([item(hoje_credito="")])
        self.assertEqual(store.audit["invalid_rows"], 1)
        with self.assertRaises(DataError):
            Engine(store).analyze()

    def test_bad_money_and_sales_credit_rejected(self):
        for invalid in ("NaN", "Infinity", "-1.00", "1.005", "1e200", ""):
            with self.assertRaises(DataError):
                money(invalid)
        store = self.load([item(2, "venda", hoje_credito="0.00")])
        self.assertEqual(store.audit["invalid_rows"], 1)

    def test_base_items_enrich_without_overwriting_reference(self):
        row = item()
        write_csv(self.root / "base_completa_meridional.csv", [row])
        write_csv(self.root / "base_itens.csv", [{"chave": row["chave"], "nItem": "1", "descricao": "Produto testado", "NCM": "00123456", "fornecedor": "A", "cClassTrib": "200003", "hoje_credito": "0.00", "vProd": "200.00", "perspectiva": "venda"}])
        store = DataStore(self.root)
        self.assertEqual(store.rows[0]["produto"], "Produto testado")
        self.assertEqual(store.rows[0]["NCM"], "00123456")
        self.assertEqual(store.rows[0]["cClassTrib"], "000001")
        self.assertEqual(store.rows[0]["hoje_credito"], "10.00")
        self.assertEqual(store.rows[0]["vProd"], "100.00")
        self.assertEqual(store.rows[0]["perspectiva"], "compra")

    def test_partial_complement_coverage_blocks_company_total(self):
        rows = [item(), item(2)]
        write_csv(self.root / "base_completa_meridional.csv", rows)
        (self.root / "simulacao.json").write_text(json.dumps(simulation(rows[:1])))
        store = DataStore(self.root)
        self.assertEqual(store.audit["joins"]["simulation"]["missing_in_complement"], 1)
        with self.assertRaises(DataError):
            Engine(store).analyze()

    def test_final_csv_and_json_have_priority_without_rewriting(self):
        row = item()
        write_csv(self.root / "base_completa_meridional.csv", [row])
        final = dict(row, confianca="0.75", fonte="CSV final da equipe")
        write_csv(self.root / "v5" / "itens_classificados.csv", [final])
        sim = dict(row, hoje_credito="12.00")
        (self.root / "v5" / "simulacao.json").write_text(json.dumps(simulation([sim])))
        store = DataStore(self.root)
        self.assertEqual(store.rows[0]["fonte"], "CSV final da equipe")
        self.assertEqual(store.rows[0]["hoje_credito"], "12.00")
        self.assertEqual(Engine(store).analyze()["totals"]["hoje"]["creditos"], "12.00")
        self.assertTrue(store.verify_originals()["ok"])

    def test_summary_conflict_blocks_totals(self):
        row = item()
        write_csv(self.root / "base_completa_meridional.csv", [row])
        payload = simulation([row])
        payload["resumo"] = [{"cenario": s, "debitos_vendas": "0.00", "creditos_compras": "99.00", "imposto_liquido": "-99.00"} for s in ("hoje", "2027", "2033")]
        (self.root / "simulacao.json").write_text(json.dumps(payload))
        store = DataStore(self.root)
        self.assertFalse(store.audit["json_summary_check"]["ok"])
        with self.assertRaises(DataError):
            Engine(store).analyze()

    def test_item_level_rounding_cbs_ibs_separate(self):
        row = item(vProd="0.06", hoje_imposto="0.00", hoje_credito="0.00", **{"2033_imposto": "0.02", "2033_credito": "0.02"})
        engine = Engine(self.load([row]))
        report = engine.project(percent="0", confirmed=True)
        # .06*.088=.00528 -> .01; .06*.177=.01062 -> .01.
        self.assertEqual(report["hypothetical"]["totals"]["2033"]["creditos"], "0.02")

    def test_mutated_source_refuses_stale_computations_and_exports(self):
        store = self.load([item()])
        engine = Engine(store)
        with (self.root / "base_completa_meridional.csv").open("a") as stream:
            stream.write("\n")
        self.assertFalse(store.verify_originals()["ok"])
        for operation in (engine.analyze, engine.records, engine.classification):
            with self.assertRaises(DataError):
                operation()

    def test_classification_mismatch_preserved_and_projection_blocked(self):
        store = self.load([item(cClassTrib="200003")])
        self.assertEqual(store.audit["class_simulation_divergences"], 1)
        self.assertEqual(Engine(store).analyze()["totals"]["2033"]["creditos"], "26.50")
        with self.assertRaises(DataError):
            Engine(store).project(confirmed=True)

    def test_credit_ranking_by_supplier_reconciles_and_keeps_sales_category(self):
        store = self.load([item(fornecedor="Fornecedor A"), item(2, fornecedor="Fornecedor B", hoje_credito="0.00"), item(3, "venda")])
        engine = Engine(store)
        credits = engine.analyze(group_by="fornecedor", metric="creditos")
        self.assertEqual(credits["metric_total"], "53.00")
        self.assertEqual(sum(Decimal(r["value"]) for r in credits["metric_ranking"]), Decimal("53.00"))
        sale = next(r for r in credits["metric_ranking"] if r["label"] == "Não se aplica — vendas")
        self.assertEqual(sale["value"], "0.00")
        increases = engine.analyze(group_by="fornecedor", metric="purchase_effect")
        self.assertEqual(increases["metric_ranking"][0]["label"], "Fornecedor B")
        self.assertEqual(increases["metric_total"], increases["purchase_effect"])

    def test_credit_disagreement_audited_preserved_and_projection_zero_blocked(self):
        store = self.load([item(**{"2033_credito": "27.00"})])
        engine = Engine(store)
        self.assertEqual(store.audit["recalculation_2033"]["differences"], 0)
        self.assertEqual(store.audit["recalculation_2033"]["credit_differences"], 1)
        self.assertEqual(engine.analyze()["totals"]["2033"]["creditos"], "27.00")
        with self.assertRaises(DataError) as caught:
            engine.project(percent="0", confirmed=True)
        self.assertEqual(caught.exception.code, "projection_unavailable")
        self.assertTrue(store.verify_originals()["ok"])


if __name__ == "__main__":
    unittest.main()
