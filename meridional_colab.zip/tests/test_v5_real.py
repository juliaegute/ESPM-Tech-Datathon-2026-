"""Tests using the v5 ZIP and base_itens actually supplied by the user.

The LLM is not called; conversation checks select the explicit limited local
provider. Independent controls are calculated directly from ZIP/CSV with Decimal.
"""
import csv
from decimal import Decimal as D
import hashlib
import json
from pathlib import Path
import zipfile

import pytest
from meridional.data import DataStore
from meridional.engine import Engine
from meridional.conversation import Conversation, LocalProvider
from meridional.sources import SourceBook

ROOT=Path(__file__).resolve().parents[1]


@pytest.fixture(scope='module')
def real():
    store=DataStore(ROOT)
    return store,Engine(store),SourceBook(ROOT)


@pytest.fixture(scope='module')
def raw():
    with zipfile.ZipFile(ROOT/'data/originais/entrega_meridional_v5.zip') as z:
        final=list(csv.DictReader(z.read('Meridional/itens_classificados.csv').decode('utf-8-sig').splitlines(),delimiter=';'))
        payload=json.loads(z.read('Meridional/simulacao.json'),parse_float=D)
    with (ROOT/'data/originais/base_itens.csv').open(encoding='utf-8-sig',newline='') as f:
        base=list(csv.DictReader(f,delimiter=';'))
    key=lambda r:(r['chave'],str(r['nItem']))
    return {key(r):r for r in final},{key(r):r for r in payload['itens']},{key(r):r for r in base}


def test_three_way_join_is_complete_and_reference_hash_verified(real):
    store,engine,_=real
    assert store.capabilities['reference_package_loaded']
    assert store.audit['reference_package']['sha256']==hashlib.sha256((ROOT/'data/originais/entrega_meridional_v5.zip').read_bytes()).hexdigest()
    assert not store.audit['blockers']
    for join in store.audit['joins'].values():
        assert join=={'matched':15000,'only_in_complement':0,'missing_in_complement':0,'duplicate_keys':0}
    assert engine.analyze()['coverage']['reference_coverage_verified']
    assert not engine.analyze()['coverage']['company_completeness_verified']
    assert store.audit['missing_files']==['ZIP com os dados originais (DANFEs, cadastros e tabelas)']


def test_every_classification_and_simulation_comes_from_v5(real,raw):
    store,_,_=real
    final,sim,base=raw
    for row in store.rows:
        key=row['chave'],row['nItem']
        for field in ('cClassTrib','status','confianca','imposto_seletivo','fonte'):
            assert row[field]==final[key][field]
        assert row['produto']==base[key]['cProd']
        assert row['descricao']==base[key]['descricao']
        assert row['NCM']==base[key]['NCM']
        for year in ('hoje','2027','2033'):
            for field in ('imposto','credito'):
                value=sim[key][year][field]
                assert row[f'{year}_{field}']=='' if value is None else D(row[f'{year}_{field}'])==D(str(value))


def test_differences_are_sources_not_money_or_reclassification(real):
    store,_,_=real
    changes=[i for i in store.audit['issues'] if i['code']=='reference_difference']
    assert len(changes)==1
    assert changes[0]['count']==153 and changes[0]['fields']=={'fonte':153}
    assert store.audit['correction_history']['consolidated_marked_items']==677
    assert store.audit['correction_history']['v5_ledger_rows']==524


@pytest.mark.parametrize('year',['hoje','2027','2033'])
def test_full_new_dimensions_reconcile_without_dropping_rows(real,year):
    store,engine,_=real
    for group in ('produto','fornecedor','destinatario','finalidade'):
        a=engine.analyze(year,group_by=group)
        assert sum(D(r['gain'])for r in a['ranking'])==D(a['gain'])
        assert sum(r['count']for r in a['ranking'])==15000
        assert not a['coverage']['warnings']
    products=engine.analyze(year,group_by='produto')['ranking']
    assert len(products)==95 # 128 description spellings are not 128 products.
    assert store.audit['entity_counts']=={'products':95,'descriptions':128,'suppliers':19,'recipients':8}


def test_supplier_credit_values_are_independently_summed(real,raw):
    _,engine,_=real
    _,sim,base=raw
    report=engine.analyze('2033',{'perspectiva':'compra'},'fornecedor',metric='creditos')
    assert len(report['metric_ranking'])==19
    for group in report['metric_ranking']:
        expected=sum((D(str(sim[k]['2033']['credito']))for k,r in base.items() if r['perspectiva']=='compra'and r['emitente_nome']==group['label']),D(0))
        assert D(group['value'])==expected
    assert report['metric_ranking'][0]['label']=='PLASVIDA ARTEFATOS PLASTICOS LTDA'
    assert report['metric_ranking'][0]['value']=='36178740.98'


def test_purchases_scope_and_not_applicable_sales_reconcile(real):
    store,engine,_=real
    report=engine.analyze(group_by='fornecedor')
    na=next(x for x in report['ranking']if x['label']=='Não se aplica — vendas')
    assert na['count']==3300 and na['purchase_effect']=='0.00'
    assert all(r['perspectiva']=='compra' for r in store.filter_rows({'fornecedor':'PLASVIDA ARTEFATOS PLASTICOS LTDA'}))


@pytest.mark.parametrize('label',['uso_consumo','uso e consumo'])
def test_use_consumption_normalization_uses_real_960_items(real,label):
    _,engine,_=real
    report=engine.analyze('2033',{'finalidade':label})
    assert report['count']==960
    assert report['totals']['hoje']['creditos']=='0.00'
    assert report['totals']['2027']['creditos']=='21615918.26'
    assert report['totals']['2033']['creditos']=='65093390.80'
    full=engine.analyze(group_by='finalidade')
    assert {r['label']for r in full['ranking']}=={'revenda','uso e consumo','Não se aplica — vendas'}
    assert full['coverage']['dimension_coverage']['finalidade']['complete']


def test_real_supplier_followup_and_product_drilldown_preserve_scope(real):
    _,engine,sources=real
    c=Conversation(engine,sources,LocalProvider())
    first=c.ask('Analise o fornecedor PLASVIDA em 2033')
    assert first.error is None and first.analysis['gain']=='36178740.98'
    later=c.ask('E em 2027?')
    assert later.error is None and later.analysis['gain']=='12014072.34'
    result=c.ask('Quais produtos explicam esse ganho?')
    assert result.analysis['scenario']=='2027'
    assert c.context['filters']['fornecedor']=='PLASVIDA ARTEFATOS PLASTICOS LTDA'
    assert result.analysis['group_by']=='produto'


def test_ambiguous_product_requests_a_code_before_calculating(real):
    _,engine,sources=real
    c=Conversation(engine,sources,LocalProvider())
    before=dict(c.context)
    a=c.ask('Analise o produto arroz em 2033')
    assert a.kind=='clarify' and a.analysis is None
    assert c.context==before


def test_classification_cites_final_csv_and_base_but_not_missing_danfe(real):
    _,engine,sources=real
    c=Conversation(engine,sources,LocalProvider())
    answer=c.ask('Por que o produto DIVERSOS recebeu essa classificação?')
    assert answer.kind=='classification' and answer.error is None
    assert c.context['filters']['produto']=='DIV001'
    assert 'NCM 39269090' in answer.text
    assert {'itens_classificados.csv','base_itens.csv'} <= {e['source']for e in answer.evidence}
    assert all(Path(e['path']).is_file() for e in answer.evidence)
    assert 'não comprova a correção' in answer.text


def test_new_original_files_and_all_runtime_sources_preserved(real):
    store,_,_=real
    manifest=json.loads((ROOT/'docs/complementos.sha256.json').read_text())
    assert all(hashlib.sha256((ROOT/'data/originais'/n).read_bytes()).hexdigest()==d for n,d in manifest.items())
    assert store.verify_originals()['ok']
