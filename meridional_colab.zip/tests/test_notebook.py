"""Validação estrutural e execução da conversa direta em Python local.

Não são testes nativos do Colab: upload, segredo e iframe do Google não são
executados. A saída IPython é substituída só para verificar o código de conversa.
"""
import ast
import builtins
import hashlib
import json
from pathlib import Path
import sys
from types import ModuleType

import nbformat

ROOT=Path(__file__).resolve().parents[1]


def notebook():
    return nbformat.read(ROOT/'Meridional_IA.ipynb',as_version=4)


def test_notebook_valid_and_python_cells_compile():
    nb=notebook()
    nbformat.validate(nb)
    code=[c.source for c in nb.cells if c.cell_type=='code']
    assert len(code)==7
    for text in code:
        ast.parse('\n'.join(line for line in text.splitlines() if not line.startswith('%')))
    assert 'share=False' in '\n'.join(code)
    assert 'default_local=not USAR_IA' in '\n'.join(code)


def test_direct_notebook_conversation_executes_real_engine_with_context(monkeypatch):
    nb=notebook()
    text=next(c.source for c in nb.cells if c.cell_type=='code' and '# 5 ·' in c.source)
    questions=iter(['Analise a classe 000001 em 2033','E em 2027?','O que é CBS segundo os materiais?','sair'])
    monkeypatch.setattr(builtins,'input',lambda prompt: next(questions))
    display_module=ModuleType('IPython.display')
    captured=[]
    display_module.display=captured.append
    display_module.Markdown=lambda text:text
    monkeypatch.setitem(sys.modules,'IPython.display',display_module)
    ns={'DESTINO':ROOT,'USAR_IA':False}
    exec(compile(text,'notebook-conversa-direta','exec'),ns)
    c=ns['conversa_direta']
    assert len(c.history)==3
    assert c.context['scenario']=='2027'
    assert c.context['filters']=={'cClassTrib':'000001'}
    assert c.history[0]['answer'].analysis['gain']=='65199052.30'
    assert 'página 3' in captured[-1]
    assert 'Modo local limitado' in captured[-1]


def test_all_uploaded_originals_still_match_initial_manifest():
    manifest=json.loads((ROOT/'docs/originais.sha256.json').read_text())
    assert len(manifest)==5
    assert all(hashlib.sha256((ROOT/'data/originais'/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items())
