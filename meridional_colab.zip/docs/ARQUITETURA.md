# Arquitetura e limites de confiança

## Fluxo de uma pergunta

1. A interface cria uma `Conversation` por sessão. Cenário, filtros, agrupamento, métrica, referências e hipóteses pendentes pertencem a essa conversa.
2. `OpenAIProvider` envia pergunta e contexto resumido à API OpenAI. A resposta deve obedecer a um JSON Schema estrito: ação, cenário, filtros e parâmetros de ferramentas conhecidas. Não existe ferramenta de código, SQL livre, busca na internet, gravação ou reclassificação.
3. `Conversation` valida o plano novamente em Python. Campos, cenários e métricas fora do catálogo são recusados. Aliases são normalizados sem deixar `null` apagar filtros existentes. Hipóteses exigem percentual e sentido presentes na pergunta ou em uma hipótese pendente previamente validada.
4. `Engine` processa integralmente os itens do recorte. Busca documental e ranking exibido nunca determinam o universo da soma. Dinheiro usa `Decimal` e `ROUND_HALF_UP`; cada CBS e IBS é arredondado antes da soma.
5. `SourceBook` lê os PDFs e DOCXs originais. As citações apontam a página/parágrafo real ou a linha/chave/nItem do dado. Os arquivos de texto extraídos em `docs` são somente auxiliares de leitura, não substituem os PDFs. A integridade dos originais é conferida antes de usar o conteúdo carregado.
6. A resposta é composta localmente com números calculados e trechos disponíveis. O LLM não escreve valores financeiros nem regras tributárias livres. Documentos e campos textuais são dados, nunca instruções de sistema.

Essa escolha favorece rastreabilidade: a interpretação de linguagem natural usa IA real, enquanto a explicação final é restringida aos fatos calculados e às fontes presentes. Não equivale a garantir que qualquer pergunta possível tenha ferramenta implementada.

## Organização

| Arquivo | Responsabilidade |
|---|---|
| `meridional/data.py` | CSV/JSON, tipos textuais, prioridade das fontes, junções, cobertura e auditoria |
| `meridional/engine.py` | Totais, contribuições, métricas, rankings completos, projeção e evidências |
| `meridional/sources.py` | Leitura documental, localização, recuperação e conceitos sustentados |
| `meridional/conversation.py` | Provedor real, modo local explícito, validação, contexto e composição |
| `meridional/ui.py` | Gradio conectado ao Python, sessões, gráficos, fontes e exportação |
| `meridional/imports.py` | Importação aditiva de ZIP, sem execução de scripts ou sobrescrita |
| `Meridional_IA.ipynb` | Instalação, segredo, interface privada e conversa direta alternativa |

## Dados, prioridades e cobertura

A chave de junção é `chave + nItem`. Chave, NCM, CFOP e cClassTrib permanecem texto. `correcao_produto` é histórico parcial e não vira uma dimensão completa de produto.

A entrega v5 indicada pelo usuário foi recebida como ZIP preservado; os hashes dos membros e do arquivo original são conferidos pelo manifesto de importação. CSV final, JSON e base de itens cobrem os mesmos 15.000 pares sem duplicatas. Isso não certifica autoria, acurácia das classificações nem documentos primários ausentes. O consolidado inicial permanece preservado para comparação histórica. Quando arquivos complementares são importados, CSV final fornece classificação/status/confiança/IS/fonte; JSON fornece os valores simulados; base de itens enriquece metadados sem reescrever os campos fiscais. Divergências são registradas em memória e nos relatórios; os originais nunca são corrigidos. Arquivos homônimos ambíguos não são escolhidos silenciosamente. Duplicatas e divergências de cobertura relevantes bloqueiam agregações, em vez de produzir total empresarial parcial.

A presença de um nome de DANFE ou XLSX no campo `fonte` comprova apenas uma declaração no CSV. Sem o arquivo original, a aplicação não certifica seu conteúdo nem a classificação. Confiança e status recebidos não são recalculados ou promovidos pela aplicação.

Os agrupamentos separam papéis. Fornecedor não se aplica às vendas; destinatário não se aplica às compras. Grupos sem metadados ficam visíveis como não informados, com contagens. A cobertura global e por dimensão acompanha o resultado. As novas dimensões vêm de `base_itens.csv`. Produto é identificado por `cProd` (95 códigos), preservando 128 descrições registradas como variantes. Fornecedor usa emitente somente nas compras; destinatário usa o destinatário somente nas vendas. `uso_consumo` recebe o alias de filtro `uso e consumo`, sem alterar o valor original de `finalidade_compra`. A base possui 19 fornecedores, 8 destinatários de venda e 960 itens de uso e consumo. Valores formatados como 100.0 e 100.00 não são tratados como divergência monetária.

## Métricas e hipóteses

O ranking completo de ganho usa a soma das contribuições e reconcilia com o ganho do recorte. Créditos, débitos, valor das compras e valor das vendas têm métricas próprias: não são renomeações de ganho. Gráficos de contribuições são identificados como tais; a resposta textual informa a métrica consultada.

A projeção implementada escala o valor de cada item pelo mesmo fator de preço em 2033, com quantidades e mix explicitamente constantes. O cenário hoje permanece a referência monetária original. Novo vProd, CBS e IBS são arredondados por item. O resultado preserva separadamente `reference`, `hypothetical`, parâmetros e impacto contra a referência. Divergências existentes de recálculo impedem uma projeção que atribuiria uma correção ao efeito da hipótese.

A ferramenta não calcula variação de quantidade, mix, crescimento, margens ou caixa sem os campos e definições necessários. A ferramenta de hipótese para hoje/2027 ainda não foi implementada e validada por componente. Não se alega ausência de campos que passaram a existir na base nova. Variações de quantidade/mix também exigem ferramenta específica, ainda não implementada; o agente informa essa limitação. Preço menor/maior não implica demanda constante fora da hipótese: isso é um cenário explícito, não uma previsão.

## Sessões, interface e acesso

Gradio foi escolhido por conectar eventos e estado Python à interface no notebook, sem exigir um frontend compilado. A caixa de pergunta fica antes do histórico e dos indicadores. Enviar e a entrada são bloqueados durante processamento; uma segunda proteção impede duas execuções na mesma conversa. Histórico, filtros, chave de API e exportações são separados por sessão. O campo de chave é protegido e limpo após configuração.

O servidor escuta em `127.0.0.1`, `share=False`; nenhum túnel Gradio público é criado. No Colab o notebook usa o proxy de porta autenticado da própria sessão. Isso não é uma implantação multiusuário pública com autenticação e controle de acesso próprios. Não há autorização para publicar os dados.

CSV/JSON derivados são gerados em diretórios temporários por sessão. Fórmulas de planilha em campos textuais são neutralizadas. Os originais podem ser baixados por fontes existentes. Não é liberado acesso genérico ao filesystem.

## O que sai do ambiente

O modo IA faz uma requisição HTTPS por pergunta para `api.openai.com`, usando `gpt-4.1-mini` por padrão. Envia pergunta, filtros/cenário/agrupamento/métrica, nomes de ferramentas e campos, inventário documental e até três perguntas recentes com seus tipos. Uma projeção pendente pode incluir a pergunta e os parâmetros já declarados. Não envia as linhas da base nem usa trechos recuperados como mensagens de sistema.

A chave vem do campo protegido ou do segredo `MERIDIONAL_API_KEY` (aceita também `OPENAI_API_KEY` já injetado). Nunca é gravada no pacote, nos exports ou em logs de aplicação. A assinatura do ChatGPT não substitui conta/créditos da API.

O modo local não chama modelo e é identificado explicitamente. Falha de API não o ativa. Erros de credencial, faturamento, limite temporário, modelo, rede e leitura dos dados são diferenciados de ausência de informação empresarial.
