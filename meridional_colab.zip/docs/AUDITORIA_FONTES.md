# Auditoria das fontes — referência v5 incorporada

Atualização de 17/10/2026, após o recebimento de `entrega_meridional_v5.zip` e `base_itens.csv`. Esta auditoria substitui o diagnóstico inicial de arquivos faltantes. O diagnóstico anterior está preservado em [histórico](historico/AUDITORIA_FONTES.md).

## Originais, prioridade e integridade

Os cinco anexos iniciais permanecem intactos. Dois novos originais estão em `data/originais/`: ZIP v5 (611.477 bytes) e base de itens (6.152.099 bytes). Seus hashes estão em [complementos.sha256.json](complementos.sha256.json); os cinco primeiros, em [originais.sha256.json](originais.sha256.json).

O ZIP foi extraído de forma aditiva em `data/complementares/`, com cópia preservada e manifesto. Contém `Meridional/itens_classificados.csv`, `Meridional/simulacao.json`, `correcoes_aplicadas.csv` e `gerar_entrega_final.ipynb`. **O notebook recebido não foi executado**: é fonte de dados, não instrução para alterar o agente. Nenhum arquivo, classe, status ou confiança original foi corrigido pelo aplicativo.

A referência selecionada é o pacote enviado pelo usuário como v5. A integridade entre ZIP e membros é conferida pelo manifesto. A autoria, a acurácia da classificação e documentos primários continuam sem certificação independente. Valores vêm do JSON v5; classificação/status/confiança/IS/fonte vêm do CSV final; os metadados vêm da base de itens. O consolidado anterior serve à comparação histórica e não substitui esses arquivos.

## Cobertura da junção

| Fonte | Registros | Pares chave+nItem | Duplicatas | Sem correspondência |
|---|---:|---:|---:|---:|
| CSV final v5 | 15.000 | 15.000 | 0 | 0 |
| JSON v5 | 15.000 | 15.000 | 0 | 0 |
| base_itens.csv | 15.000 | 15.000 | 0 | 0 |
| Consolidado anterior | 15.000 | 15.000 | 0 | 0 |

Há 1.387 chaves de nota, 11.700 itens de compra e 3.300 de venda. Nenhuma linha foi descartada. Chave, NCM, CFOP, cProd e códigos tributários permanecem texto. A cobertura integral é da referência recebida; não implica conferência com DANFEs ou com um universo externo não fornecido.

## Divergências e seu impacto

- **153 diferenças no campo `fonte`** entre CSV final e consolidado. Os textos da v5 prevalecem em memória por serem a referência escolhida. Classe, status, confiança e sinalização de IS não diferem. Isso não é uma reclassificação feita pelo aplicativo.
- **Zero diferenças numéricas** nos impostos, créditos e alíquotas efetivas dos três cenários entre JSON v5 e consolidado. Os totais anteriores são confirmados pelo JSON recebido.
- **Zero conflitos de perspectiva ou de valor numérico de vProd** entre base de itens e referência. Há 4.014 diferenças de escrita de vProd (por exemplo `303690.0` e `303690.00`); são representação numérica equivalente, sem diferença monetária.
- O consolidado registra **677 itens com histórico de correção**. O arquivo `correcoes_aplicadas.csv` da v5 contém **524 linhas**. São históricos de origens distintas, preservados e identificados; não são tratados como o mesmo inventário e o ledger não é reaplicado ao CSV final.

A evidência integral, com rankings completos, está em [auditoria-v5.json](evidencias/auditoria-v5.json). O script `python scripts/auditar_v5.py` calcula esse relatório diretamente dos anexos, independentemente do motor da aplicação.

## Metadados que agora podem ser analisados

| Dimensão | Cobertura observada |
|---|---:|
| Produtos por cProd | 95 códigos |
| Descrições registradas | 128 variantes |
| Fornecedores das compras | 19 |
| Destinatários das vendas | 8 |
| Compras para revenda | 10.740 itens |
| Compras para uso e consumo | 960 itens |
| Vendas, finalidade de compra não aplicável | 3.300 itens |

O agrupamento por produto usa **cProd**, preservando descrições variantes; não transforma 128 grafias em 128 produtos. Fornecedor é emitente somente nas compras; vendas ficam em “Não se aplica — vendas”. Destinatário é agrupado nas vendas; compras ficam em “Não se aplica — compras”. A finalidade é aplicável às compras, com vendas em categoria não aplicável.

O valor original `finalidade_compra=uso_consumo` é preservado. O filtro reconhece também “uso e consumo”. Essa associação é explícita; finalidade não é inferida de crédito zero. Nome parcial de produto/fornecedor só é resolvido se houver uma correspondência nos registros; múltiplas correspondências exigem esclarecimento.

## Totais da v5

| Cenário | Débitos das vendas | Créditos das compras | Imposto líquido | Ganho contra hoje |
|---|---:|---:|---:|---:|
| hoje | R$ 524.204,08 | R$ 2.055.856,72 | R$ -1.531.652,64 | R$ 0,00 |
| 2027 | R$ 540.295,24 | R$ 24.242.989,24 | R$ -23.702.694,00 | R$ 22.171.041,36 |
| 2033 | R$ 354.164,39 | R$ 67.962.518,42 | R$ -67.608.354,03 | R$ 66.076.701,39 |

O resumo do JSON confere com a soma de todos os seus itens. Em 2033, as contribuições são R$ 170.039,69 nas vendas e R$ 65.906.661,70 nas compras, somando R$ 66.076.701,39. CBS e IBS foram conferidos separadamente por item com Decimal/ROUND_HALF_UP, sem substituir valores registrados.

## Produtos que mais contribuem em 2033

| cProd | Itens | Ganho |
|---|---|---|
| MP4521 | 171 | R$ 38.395.434,04 |
| EMBAL1 | 163 | R$ 11.865.935,72 |
| DIV001 | 160 | R$ 8.703.579,99 |
| MISC01 | 149 | R$ 5.918.333,87 |
| INT6FV | 158 | R$ 643.892,94 |

Produtos com contribuição negativa:

| cProd | Itens | Ganho |
|---|---|---|
| QUEMIN | 154 | R$ -89.717,68 |
| FJC5KG | 169 | R$ -60.735,63 |
| QUEBRA | 150 | R$ -55.407,03 |
| QUEMOZ | 160 | R$ -55.043,36 |
| ARZ5P | 198 | R$ -47.155,66 |

Os 95 grupos completos reconciliam com o ganho total. Descrições como DIVERSOS/MATERIAL CONF PED são mantidas sem inventar especificações técnicas.

## Fornecedores com mais créditos em 2033

| Fornecedor | Itens | Créditos | Aumento contra hoje |
|---|---|---|---|
| PLASVIDA ARTEFATOS PLASTICOS LTDA | 533 | R$ 36.178.740,98 | R$ 36.178.740,98 |
| PLASTICOS NACIONAL INDUSTRIA LTDA | 427 | R$ 28.914.649,82 | R$ 28.914.649,82 |
| HOSPITALAR CENTRAL DISTRIBUIDORA LTDA | 738 | R$ 1.025.962,40 | R$ 1.025.962,40 |
| MEDPRIME ARTIGOS HOSPITALARES LTDA | 490 | R$ 634.286,84 | R$ 634.286,84 |
| PANIFICACAO GOLDEN LTDA | 670 | R$ 269.239,60 | R$ -4.538,63 |

Esses créditos somam R$ 67.962.518,42 nos 19 fornecedores. O aumento total dos créditos é R$ 65.906.661,70, métrica distinta do crédito total. O ganho do recorte integral também inclui a contribuição das vendas na categoria não aplicável ao fornecedor.

## Uso e consumo

Nos 960 itens identificados explicitamente como uso_consumo, vProd soma R$ 245.635.436,75. Créditos registrados: hoje R$ 0,00; 2027 R$ 21.615.918,26; 2033 R$ 65.093.390,80. Não há vendas nesse filtro. O ganho de 2033 desse recorte é R$ 65.093.390,80, ampliação do saldo credor simulado; não representa lucro ou caixa recebido.

## Pendências e limites

Continua faltando o **ZIP original com DANFEs, cadastros e tabelas**, inclusive os XLSX citados pelas justificativas. `arquivo_origem` e `pagina_origem` na base permitem localizar o documento declarado, mas não comprovam o conteúdo da DANFE ausente. A classificação é consultada como fato registrado na v5, com a evidência do CSV e do metadado recebido.

Os materiais iniciais têm divergências de avaliação (70/30 no enunciado versus 35/65 na apresentação) e contagem de clientes (a apresentação declara sete e enumera nove). A base recebida tem oito destinatários de vendas. Nenhuma dessas diferenças foi “corrigida” nem usada para criar regra tributária. Vale o recorte efetivamente disponível e identificado.

A ferramenta de hipótese implementada altera preços em 2033, com quantidades e mix explicitamente constantes. A nova base possui quantidade, preço unitário e componentes fiscais, mas projeções de quantidade/mix ou recálculos hipotéticos de hoje/2027 ainda exigem ferramentas específicas, não implementadas. Os resultados de referência hoje/2027/2033 continuam consultáveis.

API real e Colab nativo continuam sem execução nesta máquina; o relatório de testes distingue essas pendências dos testes locais.
