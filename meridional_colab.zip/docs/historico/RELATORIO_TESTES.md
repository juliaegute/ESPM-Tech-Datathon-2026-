# Histórico da entrega inicial, antes dos novos anexos

# Relatório de testes e limitações

Executado em 17/10/2026, Python 3.12.14, Linux, instalação Python isolada e Chromium local. As cinco fontes recebidas foram preservadas. O objetivo validado é o fluxo com o consolidado disponível, sem afirmar equivalência com a entrega v5 ausente.

## Resultados por categoria

| Categoria | Executados | Resultado | O que demonstra |
|---|---:|---|---|
| Motor determinístico | 25 | 25 passaram | Totais integrais, métricas, reconciliação, ingestão e projeção |
| Importação de arquivos | 8 | 8 passaram | ZIP preservado, sem sobrescrita ou execução, rejeição de caminhos inseguros/duplicados |
| Conversa/provedor unitários | 16 | 16 passaram | Conceitos/fontes, modo local, validação e erros HTTP simulados |
| Respostas/planos simulados do modelo | 39 | 39 passaram | Contrato de ferramentas, filtros, contexto, ausências e hipóteses; **não são chamadas reais de IA** |
| Callbacks da interface | 10 | 10 passaram | Estado, envio, duplicatas, exportação e configuração; não substituem teste de navegador |
| Notebook em Python local | 3 | 3 passaram | Estrutura, sintaxe, integridade e conversa direta com cálculos/contexto; saída IPython substituída no teste |
| **Total pytest** | **101** | **101 passaram; zero falhas, erros ou skips** | Arquivo JUnit disponível abaixo |
| Navegador real, modo local explícito | 16 verificações | 16 passaram | Caminho completo da interface ligada ao servidor Python, desktop e viewport móvel |
| Modelo real OpenAI | 0 | **Não executado** | Chave ausente; nenhum pedido foi enviado ao provedor |
| Google Colab nativo | 0 | **Não executado** | Upload, segredo, proxy/iframe e interface no serviço Google continuam pendentes |

Instalação limpa: `python -m venv /workspace/.venvs/meridional-runtime`, instalação de `requirements.txt` e depois `requirements-dev.txt`. `pip check` não apontou dependências quebradas. Cálculo integral e consulta de conceito com PDF foram executados nesse ambiente. O servidor usado no teste final de navegador também foi iniciado com esse Python isolado.

Comandos de validação:

```bash
python -m pytest -q --junitxml=outputs/testes-unitarios.xml
python app.py
# Em outro terminal, com servidor ativo e sem chave injetada:
python scripts/testar_interface.py --chromium /usr/bin/chromium
# Com chave fornecida com segurança; não executado nesta entrega:
python scripts/testar_api.py --executar
```

Evidências: [JUnit](../evidencias/inicial-testes-python.xml), [navegador](../evidencias/inicial-navegador.json), [estado da API real](../evidencias/inicial-api-real.json). Capturas de **execução real local em modo sem IA**, e não demonstração estática: [desktop](../evidencias/inicial-interface-desktop.png) e [móvel](../evidencias/inicial-interface-mobile.png).

## Matriz dos casos exigidos

| Caso | Execução/evidência | Limite |
|---|---|---|
| Maior ganho e maiores perdas | Todos os 15.000 itens, rankings de classes/chaves/perspectiva e paráfrases com planos simulados | Ganho não é lucro nem dinheiro recebido |
| Créditos por fornecedor | Ferramenta/métricas testadas com fixtures identificadas; base real devolve informação ausente | Cadastro de fornecedores não foi anexado; não existe ranking empresarial real de fornecedores validado |
| Uso e consumo | Conceito com material p.5, filtro com fixtures e ausência explícita na base real | Crédito zero hoje não é usado para inferir finalidade |
| Comparação hoje/2027/2033 | Totais reais e ordenação por valores com sinal | Não certifica v5 nem lucro/caixa |
| Reconciliação completa | Todos os agrupamentos disponíveis e três cenários; soma dos grupos = ganho; contribuições vendas+compras reconciliam | Gráficos/top5/top10 não restringem o universo de cálculo |
| Continuação “E em 2027?” | Filtro de fornecedor com fixture; classe 000001 na base real, callbacks e navegador | Fornecedor real depende dos arquivos faltantes |
| Conceito com fonte | CBS em PDF p.3; saldo negativo p.6; fonte recuperada após pergunta documental | Somente conteúdo efetivamente presente nos materiais |
| Classificação de produto | Produto com fixture e linha de CSV real consultável por chave+nItem; justificativa recebida distinguida de validação primária | Descrição/produto e DANFE citada estão ausentes na base real; não se certifica sua classificação |
| Projeção explícita | Preços das compras +10% em 2033, quantidades/mix constantes; referência separada, arredondamento por item e hashes preservados | Sem inferir quantidade, mix, demanda, lucro ou prazo de créditos |
| Projeção ambígua | “Compras aumentam 10%” pede esclarecimento; continuação preserva percentual e alvo | Valor total sozinho não autoriza presumir variação de preço |
| Percentual, sentido ou alvo inventado | Planos simulados que trocam 10% por 100%, aumento por redução ou compra por venda são recusados | Definições devem vir do usuário |
| Registro/fornecedor inexistente | Chave inexistente na base e fornecedor inexistente em fixture | Busca vazia não comprova inexistência fora dos arquivos; ausência não vira zero |
| Informação ausente | Prazo de ressarcimento retorna a frase exigida; pergunta parcialmente respondível preserva o cálculo suportado | Prazo não é inventado a partir de conhecimento externo |
| Futebol/fora do assunto | Mensagem de escopo testada em planos simulados e navegador local | IA real ainda precisa de teste com credencial |
| Saldo negativo e prejuízo | Definição ancorada no enunciado p.6 | Não usa saldo tributário como demonstração de resultado operacional |
| Falha de API | HTTP 401, 403, 404, 429 orçamento/limite temporário, 500 e conexão simulados; chave ausente real | Não foram geradas falhas reais de conta/faturamento/modelo |
| Campo e Enviar | Digitar, enviar, receber resposta e continuar em navegador Chromium real | Servidor local; proxy Colab não exercitado |
| Bloqueio de envio duplicado | Generator desabilita campo/botão; segunda chamada da mesma sessão não executa novamente, testado por callbacks | Não é teste de carga multiusuário público |
| Sessões independentes | Dois contextos de navegador reais: histórico, filtro e provedor não se misturam | Servidor é privado; não há autenticação pública implementada |
| Preservação dos originais | Cinco SHA-256 comparados ao manifesto inicial, testes de projeção e exportação sem mutação | Não foi autorizada nem executada correção de dados/classificações |
| Layout móvel | Viewport 390×844; largura total 390, caixa visível e sem rolagem horizontal da página | Gráficos/tabelas possuem seus controles locais |
| Notebook/fallback | Notebook válido, sete células Python verificadas; conversa direta executou base real e manteve classe/ano | Teste local com saída IPython substituída; não chama isso de execução nativa Colab |

## Valores de controle calculados no arquivo disponível

| Cenário | Débitos das vendas | Créditos das compras | Imposto líquido | Ganho versus hoje |
|---|---:|---:|---:|---:|
| Hoje | R$ 524.204,08 | R$ 2.055.856,72 | −R$ 1.531.652,64 | R$ 0,00 |
| 2027 | R$ 540.295,24 | R$ 24.242.989,24 | −R$ 23.702.694,00 | R$ 22.171.041,36 |
| 2033 | R$ 354.164,39 | R$ 67.962.518,42 | −R$ 67.608.354,03 | R$ 66.076.701,39 |

Em 2033, efeito das vendas R$ 170.039,69 e efeito das compras R$ 65.906.661,70. A soma reconcilia com R$ 66.076.701,39. CBS e IBS, arredondados separadamente por item, conferem com os 15.000 impostos e 11.700 créditos de compra de 2033. Hoje/2027 foram somados a partir dos valores recebidos: faltam componentes e cadastros para recalculá-los integralmente de forma independente.

São resultados do consolidado fornecido. As contagens de itens/notas coincidem com os materiais, mas isso não comprova identidade v5 ou cobertura integral da empresa. Os 677 registros corrigidos já vieram assim e permanecem intactos.

## Pendências externas e limites da entrega

1. Anexar `entrega_meridional_v5.zip`, `base_itens.csv` e o ZIP com dados originais. A auditoria atual não consegue conferir CSV final/JSON da v5, fornecedores, descrições, finalidade ou documentos ausentes. Importações usam os nomes/esquemas documentados; cadastros com outros esquemas exigem adaptação explícita, não adivinhação.
2. Configurar uma chave com acesso e créditos de API pelo segredo/entrada protegida e executar o teste real. Não há promessa de acurácia de interpretação do modelo sem esse teste. O modo local permanece limitado e explicitamente identificado.
3. Abrir o notebook no Colab e testar upload, segredo, proxy de porta, conversa, continuação e fonte. Se a interface não renderizar, a conversa direta é a alternativa implementada; não é um túnel público.
4. Projeções de quantidade/mix, hoje/2027, margens, caixa e prazos de ressarcimento não são calculadas com campos ausentes. A ferramenta disponível é uma hipótese explícita de preços em 2033.
5. O rascunho cloud salva instalação/inicialização e um segredo pessoal opcional `MERIDIONAL_API_KEY`, destinado somente a `api.openai.com`. Salvar rascunho não configura um valor de chave, não publica uma versão nem valida restauração em tarefa nova. Para reutilizar o ambiente, revise/salve e publique pelas configurações do produto. A aplicação não foi publicada externamente.

Não houve reclassificação nem correção da base. Divergências documentais de avaliação/clientes estão na [auditoria de fontes](AUDITORIA_FONTES.md); não foram transformadas em novas regras tributárias.
