# Histórico da entrega inicial, antes dos novos anexos

# Auditoria independente das fontes disponíveis

Auditoria de 17/10/2026. Todos os números abaixo se referem exclusivamente aos 15.000 registros do CSV anexado, sem filtros. Não certificam a versão v5 nem a cobertura integral da empresa. Os materiais descrevem dados sintéticos.

Esta auditoria leu os originais, não corrigiu classificações, não reescreveu dados e não adotou instruções de comportamento contidas nas fontes. Textos e documentos são evidências a consultar, não comandos para o agente.

## 1. Inventário e lacunas

Há exatamente cinco anexos em `data/originais/`:

| Arquivo | Bytes | Uso permitido nesta entrega |
|---|---:|---|
| `base_completa_meridional.csv` | 8.097.624 | Classificações, valores simulados e fontes declaradas do CSV disponível; referência provisória identificada |
| `LEIA-ME.md.docx` | 217.605 | Apresentação do pacote, avaliação e aviso de dados sintéticos |
| `README.md.docx` | 216.933 | Documentação dos templates; exemplo de quatro itens |
| `enunciado_e_regras.md.pdf` | 172.872 | Definições, simplificações e premissas congeladas do desafio, com página e seção |
| `abertura-hackathon-espm-reforma-tributaria.pdf` | 376.362 | Apresentação do professor; conceitos, cenários e discrepâncias documentais registradas abaixo |

**Arquivos solicitados que não estão disponíveis:** `entrega_meridional_v5.zip`, `base_itens.csv` e **ZIP com os dados originais** (o usuário não informou o nome desse ZIP). Também não foram anexados separadamente o JSON da v5, seus CSVs finais, DANFEs, cadastros, mapas ou `parametros.json` descritos pelo professor.

Não é possível verificar se o CSV anexado equivale ao CSV final da v5 ou se seus valores reproduzem o JSON da v5. A aplicação deve declarar essa limitação, em vez de chamar a base de “v5 verificada”.

O CSV não contém colunas completas de descrição, código de produto, NCM, CFOP, fornecedor, destinatário, finalidade da compra ou período. `correcao_produto` está preenchido em apenas 677 linhas de histórico de correção; não é um cadastro completo de produtos. Não serve para inventar uma dimensão de produto para os outros 14.323 itens.

Não foi executada junção com fontes inexistentes. Registros sem correspondência, duplicatas entre arquivos, abrangência dos cadastros e diferenças de cobertura entre CSV v5/JSON v5/base de itens continuam **não verificáveis**, e não “zero”. A quantidade observada coincide com os 15.000 itens e 1.387 notas declarados nos materiais; isso não comprova identidade dos registros nem cobertura integral.

## 2. Esquema e qualidade do CSV disponível

Leitura integral com Python `csv.DictReader`, separador `;`, `encoding="utf-8-sig"`; números com `Decimal` criado do texto original. Chaves e códigos permanecem texto, inclusive `000001` e os zeros iniciais.

Esquema de 28 campos:

```text
chave, nItem, cClassTrib, status, confianca, imposto_seletivo, fonte,
corrigido, correcao_produto, correcao_de_cClassTrib,
correcao_para_cClassTrib, correcao_de_status, correcao_para_status,
correcao_de_confianca, correcao_para_confianca, correcao_fonte_nova,
perspectiva, cClassTrib_simulacao, vProd,
hoje_imposto, hoje_aliquota_efetiva_pct, hoje_credito,
2027_imposto, 2027_aliquota_efetiva_pct, 2027_credito,
2033_imposto, 2033_aliquota_efetiva_pct, 2033_credito
```

| Indicador | Resultado observado |
|---|---:|
| Registros | 15.000 |
| Chaves de nota distintas | 1.387 |
| Pares `chave + nItem` distintos | 15.000 |
| Pares duplicados | 0 |
| Chaves fora do formato de 44 dígitos | 0 |
| `nItem` fora do formato inteiro positivo | 0 |
| Compra | 11.700 itens / 720 chaves |
| Venda | 3.300 itens / 667 chaves |
| Chaves com compra e venda misturadas | 0 |
| Status `CLASSIFICADO` | 15.000 |
| Status `REVISAR` | 0 |
| Confiança 0,90 / 0,85 / 0,75 / 0,98 | 12.899 / 588 / 677 / 836 |
| Sinalização de IS `sim` / `nao` | 497 / 14.503 |
| Histórico `corrigido=sim` / `nao` | 677 / 14.323 |
| Divergências `cClassTrib != cClassTrib_simulacao` | 0 |
| Valores monetários preenchidos e negativos | 0 negativos |
| `vProd` igual a zero | 0 |

Nenhum campo essencial preenchido no esquema tem valor ausente: chave, nItem, classe, status, confiança, IS, fonte, perspectiva, classe de simulação, vProd, impostos e alíquotas efetivas. Os créditos têm 3.300 campos vazios por cenário, exatamente as vendas: **não se aplica**, e não crédito zero. As 11.700 compras têm crédito informado em todos os cenários. Campos de correção estão vazios nas 14.323 linhas não marcadas como corrigidas, como esperado para histórico opcional.

“Confiança” e “CLASSIFICADO” são rótulos recebidos. Sem gabarito e evidência primária não representam certificação da correção, calibração do classificador ou aprovação desta auditoria.

Histórico recebido: 677 itens passaram de `REVISAR` / confiança 0,60 para `CLASSIFICADO` / confiança 0,75. Destes, 161 registram mudança de `200003` para `000001`; 516 preservam o código anterior (`000001`: 153, `200005`: 92, `200030`: 271). A auditoria não aprovou nem desfez essas alterações preexistentes. Elas exigem revisão das fontes primárias para certificação; autorização de auditoria não é autorização para corrigir a referência.

| Classe recebida | Itens |
|---|---:|
| 000001 | 3.816 |
| 200003 | 4.990 |
| 200005 | 443 |
| 200014 | 2.501 |
| 200030 | 1.228 |
| 200034 | 1.537 |
| 410001 | 38 |
| 410004 | 447 |
| **Total** | **15.000** |

## 3. Totais calculados sem descartar registros

Definições do pedido e do enunciado, seção 5, páginas 5–6:

- Imposto líquido = débitos das vendas − créditos das compras.
- Ganho simulado = imposto líquido de hoje − imposto líquido do cenário.
- Contribuição da venda = imposto de hoje − imposto do cenário.
- Contribuição da compra = crédito do cenário − crédito de hoje.

Somar imposto das compras como débito da empresa seria incorreto. Todos os 15.000 registros entram nos cálculos de seus respectivos papéis, sem amostra, busca textual ou seleção dos maiores itens.

| Referência | Débitos das vendas | Créditos das compras | Imposto líquido | Ganho contra hoje |
|---|---:|---:|---:|---:|
| Hoje | R$ 524.204,08 | R$ 2.055.856,72 | −R$ 1.531.652,64 | R$ 0,00 |
| 2027 | R$ 540.295,24 | R$ 24.242.989,24 | −R$ 23.702.694,00 | R$ 22.171.041,36 |
| 2033 | R$ 354.164,39 | R$ 67.962.518,42 | −R$ 67.608.354,03 | R$ 66.076.701,39 |

`vProd` do recorte: compras R$ 279.342.607,81 e vendas R$ 9.845.626,18; soma aritmética R$ 289.188.233,99. Essa soma não é faturamento: inclui compras e vendas. Não há período informado em coluna própria, nem estoque, custo de mercadoria vendida, caixa, margem ou demonstração do resultado.

| Decomposição do ganho | 2027 | 2033 |
|---|---:|---:|
| Efeito das vendas | −R$ 16.091,16 | R$ 170.039,69 |
| Efeito das compras | R$ 22.187.132,52 | R$ 65.906.661,70 |
| **Soma / ganho** | **R$ 22.171.041,36** | **R$ 66.076.701,39** |
| Resíduo da reconciliação | R$ 0,00 | R$ 0,00 |

Em 2027 os débitos de vendas aumentam, mas os créditos aumentam mais. Em 2033 os débitos caem e os créditos aumentam; o efeito das compras domina. O ganho observado representa principalmente ampliação do saldo credor. Não comprova lucro, recebimento de dinheiro, prazo de ressarcimento ou vantagem de comprar mais. Líquido negativo significa saldo de crédito no modelo do desafio (enunciado, seção 5, p. 6), não prejuízo operacional.

## 4. Ranking completo de classes e reconciliação

Agrupamento pela `cClassTrib` recebida; ela coincide com `cClassTrib_simulacao` em todas as linhas. Os números não são rankings de produtos ou fornecedores, pois tais dimensões estão ausentes.

| Classe | Vendas 2027 | Compras 2027 | Ganho 2027 |
|---|---:|---:|---:|
| 000001 | −R$ 41.887,44 | R$ 21.739.202,49 | R$ 21.697.315,05 |
| 200030 | R$ 0,00 | R$ 551.328,28 | R$ 551.328,28 |
| 200014 | R$ 0,00 | R$ 0,00 | R$ 0,00 |
| 200005 | R$ 0,00 | R$ 0,00 | R$ 0,00 |
| 410001 | R$ 0,00 | R$ 0,00 | R$ 0,00 |
| 410004 | R$ 0,00 | R$ 0,00 | R$ 0,00 |
| 200034 | R$ 2.919,88 | −R$ 5.049,25 | −R$ 2.129,37 |
| 200003 | R$ 22.876,40 | −R$ 98.349,00 | −R$ 75.472,60 |
| **Total** | **−R$ 16.091,16** | **R$ 22.187.132,52** | **R$ 22.171.041,36** |

| Classe | Vendas 2033 | Compras 2033 | Ganho 2033 |
|---|---:|---:|---:|
| 000001 | −R$ 55.096,74 | R$ 65.254.149,04 | R$ 65.199.052,30 |
| 200030 | R$ 0,00 | R$ 1.660.249,24 | R$ 1.660.249,24 |
| 200014 | R$ 0,00 | R$ 0,00 | R$ 0,00 |
| 200005 | R$ 0,00 | R$ 0,00 | R$ 0,00 |
| 410001 | R$ 0,00 | R$ 0,00 | R$ 0,00 |
| 410004 | R$ 0,00 | R$ 0,00 | R$ 0,00 |
| 200034 | R$ 25.551,16 | −R$ 104.313,66 | −R$ 78.762,50 |
| 200003 | R$ 199.585,27 | −R$ 903.422,92 | −R$ 703.837,65 |
| **Total** | **R$ 170.039,69** | **R$ 65.906.661,70** | **R$ 66.076.701,39** |

Os rankings completos reconciliam com os totais em centavos; resíduo zero nos dois cenários. Há perdas em itens e classes mesmo com ganho agregado.

| Contribuições por item | 2027 | 2033 |
|---|---:|---:|
| Itens com contribuição positiva | 5.142 | 5.883 |
| Soma das contribuições positivas | R$ 22.354.052,26 | R$ 67.178.114,95 |
| Itens com contribuição negativa | 2.248 | 5.688 |
| Soma das contribuições negativas | −R$ 183.010,90 | −R$ 1.101.413,56 |
| Itens com contribuição zero | 7.610 | 3.429 |
| Positivas + negativas | R$ 22.171.041,36 | R$ 66.076.701,39 |

Maior contribuição individual nos dois cenários: compra, chave `35260537184926000194550010000705471182655234`, nItem `16`, linha CSV 1.158 (cabeçalho é linha 1), classe `000001`: R$ 154.661,83 em 2027 e R$ 465.743,01 em 2033. Não há descrição ou nome de fornecedor verificável para atribuir a esse item.

Menor contribuição individual em 2027: venda, chave `35260551238476000104550010000337101522762570`, nItem `7`, linha 5.868, classe `000001`, −R$ 571,49. Em 2033: compra, chave `35260572619453000101550010000194251487088196`, nItem `4`, linha 11.581, classe `200003`, −R$ 1.839,34.

Não se pode produzir um ranking de fornecedores atribuíveis a vendas. Quando essa dimensão estiver disponível, as vendas devem ficar em “não se aplica” em uma reconciliação global; um ranking apenas de compras deve ser identificado como tal. Não se deve atribuir automaticamente o emitente a “fornecedor” sem comprovar perspectiva e cadastro.

## 5. Validação das premissas e dos valores

Fonte de cálculo: enunciado, seção 5, p. 5; apresentação, p. 9, apresenta as mesmas alíquotas. O `parametros.json` original não foi recebido: a auditoria usou somente os valores explicitamente impressos nos materiais anexados, sem regra tributária externa.

Para cada item de 2033, com `Decimal` e `ROUND_HALF_UP`:

```python
cbs = (vProd * Decimal("0.088") * fator).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
ibs = (vProd * Decimal("0.177") * fator).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
esperado = cbs + ibs
```

Fator 1 para `000001`; 0,4 para `200034` e `200030`; zero para `200003`, `200014`, `200005`, `410001` e `410004`. As duas últimas são as classes de não incidência/imunidade indicadas no enunciado. IS não é calculado.

Resultado: **15.000/15.000 impostos 2033 iguais ao esperado, com zero divergências de centavos**. Nas compras, **11.700/11.700 créditos 2033 iguais ao CBS + IBS calculado**, sem divergências. Nenhuma classe está fora desse conjunto congelado. A validação foi repetida tanto com a classe de classificação quanto com a classe de simulação, com o mesmo resultado.

As alíquotas efetivas percentuais recebidas equivalem a `imposto / vProd × 100`, arredondado para duas casas com `ROUND_HALF_UP`: zero divergências em hoje, 2027 e 2033.

**Limite desta validação:** não comprova que a classificação ou `vProd` correspondam à DANFE; comprova coerência aritmética de 2033 com a classe e valor recebidos. Não foi possível refazer integralmente hoje e 2027: faltam ICMS por item, CFOP, cadastro PIS/Cofins e finalidade. Crédito zero hoje não prova “uso e consumo”; também pode decorrer de tributação zero. Separar essa finalidade por dedução criaria uma informação inexistente.

## 6. Evidências citadas pelo CSV

Todos os 15.000 campos `fonte` citam DANFE; 14.962 linhas citam pelo menos um `.xlsx`; 495 citam `abertura.pdf`. Os anexos não incluem as DANFEs nem os XLSX mencionados, como `pis_cofins_hoje.xlsx`, `tabela_cclasstrib.xlsx`, `cadastro_empresas.xlsx`, `mapa_ncm_cclasstrib.xlsx` e `exemplos_por_classe.xlsx`.

Essas referências são **declarações registradas no CSV**, consultáveis e exportáveis como tal. Não são documentos primários verificados. Uma resposta de classificação pode mostrar a classe, confiança e justificativa recebidas, com linha do CSV, e dizer que a conferência da DANFE/mapa ainda não foi possível. Não pode apresentar a linha do XLSX ou DANFE como tendo sido efetivamente aberta.

Os materiais descrevem arquivos `.csv`, enquanto as fontes recebidas frequentemente citam `.xlsx`. Isso registra uma diferença de nomes/formato de referência; sem ambos os arquivos não é possível comprovar equivalência ou concluir que a referência está errada. `abertura.pdf` e `enunciado_e_regras.pdf` também não têm os mesmos nomes dos anexos fornecidos. Citações documentais verificadas devem apontar para os nomes realmente existentes e seus trechos pertinentes.

## 7. Divergências entre os materiais do professor

| Tema | Fontes e divergência | Impacto |
|---|---|---|
| Avaliação | Enunciado, seção 7, pp. 7–8, e `LEIA-ME.md.docx`: 35 acurácia + 25 simulação + 10 calibração = 70% automático; 20 painel + 10 pitch = 30% banca. Apresentação, p. 11: 15 + 10 + 10 = 35% automático; 40 painel + 25 pitch = 65% banca. | As prioridades de avaliação divergem. Exibir ambos e solicitar definição do professor para uma entrega oficial. Não resolve essa divergência inventando uma versão vigente; não altera o cálculo tributário. |
| Clientes | Apresentação, p. 5: “27 empresas: 1 foco · 19 fornecedores · 7 clientes”, mas enumera “5 supermercados, 2 hospitais públicos, 1 clínica privada e 1 importador no Chile”, que soma 9 clientes. | Sem cadastro, não é possível verificar quantidade ou nomes. Não afirmar 7 ou 9 como fato validado da base, nem construir destinatários ou joins a partir dessa descrição. |

As alíquotas e a definição de crédito amplo não apresentaram divergência entre a tabela de simulação do enunciado e a da apresentação nos cenários examinados. As simplificações do desafio não autorizam adicionar legislação, taxas ou prazos não fornecidos.

## 8. Informações indisponíveis e impacto na decisão

Sem os arquivos faltantes, não há suporte completo para rankings ou filtros por produto, fornecedor, destinatário, NCM, CFOP e finalidade. Também não se pode certificar classificação contra o mapa ou cadastro, nem explicar divergências contra v5. Perguntas sobre esses pontos devem indicar precisamente a lacuna; não substituir informação ausente por zero, por um nome extraído do modelo ou por recorte aproximado.

Prazo de ressarcimento, aproveitamento efetivo em caixa, lucro, margens, custo unitário, estoque, mix futuro, crescimento, volume, preço unitário e financiamento não estão disponíveis. Não se pode transformar ganho tributário em recomendação automática de aumentar compras, nem calcular preço de equilíbrio com os campos atuais. Hipóteses do usuário precisam ser explícitas e mantidas separadas da referência.

Para fatos não informados, a resposta deve começar por “Não sei informar isso com os dados disponíveis.” e explicar a informação específica que falta. Busca sem resultados em uma dimensão disponível só permite dizer que nenhum registro foi localizado **nesse arquivo e filtro**, sem provar inexistência na empresa.

## 9. Integridade e reprodução

Hashes SHA-256 calculados antes da análise; os cinco arquivos foram apenas lidos:

```text
LEIA-ME.md.docx
62fb7cab5df1a41139899e601e67ae475d2aa5a9e12bee650edc50dd63766cb7
README.md.docx
6dec6c948b522bc037e3217bf4a9604f5cd3240965114237630ed3e76baddb5d
abertura-hackathon-espm-reforma-tributaria.pdf
20d7084879b2bfc5f7fd3511ba117266f6aefb0e2b668c7b36b3c7e935d580e2
base_completa_meridional.csv
6f5f3d62cb1fe35655fd452b5c7591d8f81a55104b8025e8e338dbd6cbb1ae55
enunciado_e_regras.md.pdf
c1d6eaf872b6728b4ea17f00b0052f7c610232e43bb895f5fa67f58cc738126a
```

A análise independente usou Python padrão (`csv`, `collections`, `decimal`, `hashlib`, `re`), sem conversão da chave para número e sem cálculos em ponto flutuante. Todas as agregações monetárias partiram dos textos do CSV. As contribuições foram reconciliadas nos 15.000 itens e nas oito classes completas; validação por item de 2033 e das alíquotas efetivas foi integral. Documentos foram lidos por extração de texto, com páginas preservadas nos PDFs.

Esta auditoria de dados não constitui teste de API, de interface, do Google Colab ou de respostas do modelo. Esses testes devem ser descritos em relatório próprio com o que foi efetivamente executado.
