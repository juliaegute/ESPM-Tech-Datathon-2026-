# Testes após incorporar v5 e base_itens

Atualização de 17/10/2026. Python 3.12.14, ambiente virtual isolado e Chromium local. Referência: os dois novos anexos, mais os cinco originais já recebidos. O relatório anterior está no [histórico](historico/RELATORIO_TESTES.md).

## Resultados executados

| Categoria | Executados | Resultado |
|---|---:|---|
| Motor determinístico e ingestão | 25 | Passaram |
| Importação segura de arquivos | 8 | Passaram |
| Conversa/provedor unitários, incluindo falhas HTTP simuladas | 16 | Passaram |
| Planos/respostas simulados do modelo | 39 | Passaram; não são chamadas reais de IA |
| Callbacks da interface | 10 | Passaram |
| Notebook em Python local: estrutura, sintaxe e conversa direta | 3 | Passaram; não é Colab nativo |
| Novos testes com a v5 e base de itens reais recebidas | 14 | Passaram |
| **Total pytest** | **115** | **115 passaram, zero erros/falhas/skips** |
| Navegador Chromium real, servidor Python, modo local escolhido | 20 verificações | Passaram, sem erros JavaScript não tratados |
| Modelo OpenAI real | 0 | Não executado: chave ausente, nenhum pedido enviado |
| Google Colab nativo | 0 | Não executado: upload, segredo e proxy/iframe do Google ainda pendentes |

O mesmo ambiente Python limpo da entrega inicial foi usado, sem novas dependências para os anexos. O servidor do navegador foi reiniciado para carregar os arquivos novos. O notebook recebido dentro da v5 **não foi executado** e não modificou o agente.

Evidências atuais: [JUnit](evidencias/testes-python.xml), [navegador](evidencias/navegador.json), [API real](evidencias/api-real.json), [auditoria independente](evidencias/auditoria-v5.json). Capturas de execução local real, sem IA: [desktop](evidencias/interface-desktop.png) e [móvel](evidencias/interface-mobile.png).

## O que os novos testes verificam

- CSV final, JSON e base de itens têm exatamente os mesmos 15.000 pares chave+nItem, sem duplicatas, ausências ou excedentes.
- Todos os itens mantêm classificação/status/confiança/IS/fonte do CSV final, valores do JSON e código/descrição/NCM da base de itens.
- Diferenças contra o consolidado anterior: apenas 153 textos de fonte. Não houve reclassificação ou diferença monetária. As 4.014 diferenças de escrita de vProd são numericamente equivalentes, sem alteração dos originais.
- Os históricos de correção foram mantidos separados: 677 marcações recebidas no consolidado e 524 linhas no ledger da v5. O ledger não é reaplicado ao CSV final.
- Os rankings completos por produto, fornecedor, destinatário e finalidade reconciliam com o ganho em hoje/2027/2033 e incluem todos os 15.000 itens quando o recorte é integral.
- Produto usa 95 códigos cProd, preservando 128 descrições variantes. Fornecedor nas vendas e destinatário nas compras ficam em “Não se aplica”; a finalidade de compra nas vendas também é não aplicável.
- Os créditos por fornecedor são comparados a somas independentes feitas diretamente do JSON e da base de itens, sem usar o cálculo do motor como gabarito.
- `uso_consumo` e “uso e consumo” selecionam os mesmos 960 registros; a finalidade não é inferida de crédito zero.
- A pergunta sobre PLASVIDA em 2033 e a continuação “E em 2027?” mantêm fornecedor e escopo; o detalhamento por produto também preserva o fornecedor.
- Produto descrito como DIVERSOS é associado ao código DIV001 pelos dados existentes. A resposta de classificação cita CSV final e base de itens, mostrando NCM, sem certificar a DANFE ausente.
- “Produto arroz” com mais de uma correspondência exige esclarecimento antes de calcular. Nome parcial só é resolvido se a correspondência for única.
- Os hashes dos dois novos originais e dos cinco anteriores permanecem iguais aos recebidos.

## Matriz dos requisitos anteriores

| Requisito | Verificação atual |
|---|---|
| Maior ganho e maiores perdas | Dados integrais, ranks completos e paráfrases com planejamentos simulados |
| Créditos por fornecedor | Agora com os 19 fornecedores reais, somas independentes e navegador |
| Uso e consumo | Agora com os 960 itens reais, dois aliases de filtro e navegador |
| Comparação de cenários | Três cenários da v5, itens e resumo reconciliados |
| Continuação de ano com filtros | Classe e fornecedor reais no navegador; fornecedor em planos simulados |
| Conceito com fonte | CBS p.3; saldo credor p.6; consulta documental da resposta anterior |
| Classificação com evidência | Produto real, CSV final + base, distinção entre fonte declarada e DANFE ausente |
| Projeção explícita | Preços +10% em 2033, quantidades/mix constantes, referência e hipótese separadas |
| Projeção ambígua | Esclarecimento preserva percentual e alvo; sem escolher quantidade/preço/mix silenciosamente |
| Parâmetro inventado | Troca de percentual, sentido ou compras/vendas recusada em testes de plano simulado |
| Registro ou fornecedor inexistente | Não gera total zero nem afirma inexistência fora dos arquivos |
| Prazo de ressarcimento ausente | Mensagem exigida; pergunta parcialmente respondível conserva a parte calculável |
| Futebol/fora do assunto | Mensagem de escopo, sem limpar análise anterior |
| Saldo negativo versus prejuízo | Explicação ancorada no enunciado, sem concluir lucro/caixa |
| Erros de API | Taxonomia com HTTP/rede simulados; chave ausente real, sem fallback silencioso |
| Enviar/continuação/fonte/download | Caminho completo no Chromium, servidor Python real |
| Envios duplicados | Entrada/botão bloqueados e segunda chamada recusada nos callbacks |
| Duas sessões | Dois contextos reais do navegador, com filtros/histórico/provedor independentes |
| Preservação de originais | Sete anexos, dois manifestos SHA-256 e pacote extraído preservado |
| Interface móvel | Viewport390×844, campo acessível e sem rolagem horizontal da página |
| Colab alternativo | Código de conversa direta executado em Python local, com saída IPython substituída somente no teste |

## Valores de controle

| Recorte | Resultado esperado e observado |
|---|---:|
| Integral, ganho em 2033 contra hoje | R$ 66.076.701,39 |
| Integral, efeito das vendas em 2033 | R$ 170.039,69 |
| Integral, efeito das compras em 2033 | R$ 65.906.661,70 |
| Produto MP4521, ganho em 2033 | R$ 38.395.434,04 |
| Fornecedor PLASVIDA, ganho em 2033 | R$ 36.178.740,98 |
| Mesmo fornecedor, ganho em 2027 | R$ 12.014.072,34 |
| Uso e consumo, créditos em 2027 | R$ 21.615.918,26 |
| Uso e consumo, créditos em 2033 | R$ 65.093.390,80 |

Esses valores são da referência recebida; ganhos positivos podem ampliar saldo credor. Não representam lucro nem dinheiro recebido. No filtro uso e consumo não há vendas: crédito registrado hoje é R$0,00, explicitamente presente nos registros.

## Reprodução

```bash
python -m pip install -r requirements-dev.txt
python scripts/auditar_v5.py
python -m pytest -q --junitxml=outputs/testes-unitarios.xml
python app.py
# Em outro terminal, com servidor ativo e sem chave injetada:
python scripts/testar_interface.py --chromium /usr/bin/chromium
# Somente com chave segura e acesso à conta de API:
python scripts/testar_api.py --executar
python scripts/empacotar.py
```

## Pendências precisas

1. Falta o ZIP original de DANFEs, cadastros e tabelas citados. `arquivo_origem`/`pagina_origem` identificam a DANFE declarada, mas não validam seu conteúdo. O pacote v5 e a base de itens já estão incluídos; não é necessário enviá-los novamente.
2. API real permanece sem execução por falta de chave. A integração por HTTPS/JSON Schema está implementada, mas interpretação livre do modelo precisa de validação real com credencial. Modo local permanece limitado e explicitamente identificado.
3. Abertura nativa do notebook no Google Colab e seu proxy/iframe ainda não foram executados. Validação estrutural e conversa direta em Python local não são chamadas de teste Colab. O fallback direto está implementado.
4. Quantidade e preço unitário agora estão na base. Ainda não há ferramenta de hipótese de quantidade/mix ou recálculo hipotético de hoje/2027; o agente declara limitação da ferramenta, sem alegar ausência desses campos. Hoje/2027/2033 de referência continuam disponíveis. Hipótese implementada: preço em2033 com quantidades/mix explicitamente constantes.
5. A inicialização do ambiente cloud foi atualizada no rascunho. Salvar rascunho não publica versão nem valida restauração em tarefa nova; para reutilizar, revise/salve e publique pelas configurações do ambiente. A aplicação não foi publicada externamente.
