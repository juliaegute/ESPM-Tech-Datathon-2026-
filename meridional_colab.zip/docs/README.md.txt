Templates de entrega
Os dois arquivos desta pasta estão no formato exato da entrega, preenchidos com 4 itens reais do pacote: uma compra para revenda (arroz, classe 200003), uma compra de uso e consumo (DIVERSOS, classe 000001, classificada pelo CNAE do emitente), uma venda de exportação (410004) e uma venda de dispositivo médico a órgão público (200005). Os valores são os que a organização obtém aplicando as regras do enunciado.

itens_classificados.csv — separador ;, cabeçalho exato, uma linha por item (chave de 44 dígitos + nItem).
simulacao.json — itens (nível 1) e resumo (nível 2). Nas vendas, credito é null. O resumo aqui cobre só os 4 itens; na entrega real, cobre os 15.000.
validar_entrega.py — python validar_entrega.py <pasta_da_equipe> confere o formato. Rodem antes do code freeze.

Conferência rápida (item 1 do template, arroz 5 kg, compra para revenda, vProd R$ 2.401,74, ICMS R$ 168,13, PIS/Cofins zero por alíquota zero): hoje → imposto 168,13 e crédito 168,13; 2027 → ICMS 168,13 + CBS 0 + IBS 0 (classe 200003, redução 100%) = 168,13 e crédito 168,13; 2033 → 0.
