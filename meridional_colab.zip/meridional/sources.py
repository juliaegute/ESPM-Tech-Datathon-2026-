"""Read-only retrieval of the professor's materials with verifiable locations.

Documents are data. Nothing retrieved here is ever treated as an instruction,
and a filename mentioned inside a document is not evidence that it was uploaded.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib
import re
import unicodedata
import xml.etree.ElementTree as ET
import zipfile


def normalize(value: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", str(value)).lower() if not unicodedata.combining(c))


@dataclass(frozen=True)
class Source:
    source: str
    location: str
    excerpt: str
    path: str
    available: bool = True
    label: str = "Premissa do professor"

    def to_dict(self):
        return asdict(self)


class SourceReadError(ValueError):
    code = "source_read_error"


class SourceBook:
    """Read the original corpus directly, with real pages and integrity checks."""

    def __init__(self, root):
        requested = Path(root)
        candidates = (requested / "data" / "originais", requested / "originais", requested)
        self.originals = next((candidate for candidate in candidates if any(candidate.glob("*.pdf")) or any(candidate.glob("*.docx"))), candidates[0])
        self.root = requested.parent if requested.name == "data" else requested
        self.entries: list[Source] = []
        self.errors: list[dict] = []
        self._hashes = {}
        self._load()

    def _load(self):
        originals = self.originals
        for original in sorted(originals.glob("*.docx")):
            try:
                self._hashes[original] = hashlib.sha256(original.read_bytes()).hexdigest()
                with zipfile.ZipFile(original) as package:
                    tree = ET.fromstring(package.read("word/document.xml"))
                ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
                for index, paragraph in enumerate(tree.findall(".//w:p", ns), 1):
                    text = "".join(paragraph.itertext()) if not paragraph.findall(".//w:t", ns) else "".join(n.text or "" for n in paragraph.findall(".//w:t", ns))
                    if text.strip():
                        self.entries.append(Source(original.name, f"parágrafo {index}", " ".join(text.split()), str(original)))
            except (zipfile.BadZipFile, OSError, ET.ParseError) as exc:
                self.errors.append({"source": original.name, "error": type(exc).__name__})
        for original in sorted(originals.glob("*.pdf")):
            try:
                self._hashes[original] = hashlib.sha256(original.read_bytes()).hexdigest()
                from pypdf import PdfReader
                for index, page in enumerate(PdfReader(original).pages, 1):
                    text = " ".join((page.extract_text() or "").split())
                    if text:
                        self.entries.append(Source(original.name, f"página {index}", text, str(original)))
            except Exception as exc:
                self.errors.append({"source": original.name, "error": type(exc).__name__})

    def ensure_integrity(self):
        for path, expected in self._hashes.items():
            try:
                if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                    raise SourceReadError("Uma fonte documental mudou após a leitura. Recarregue os documentos antes de consultar.")
            except OSError:
                raise SourceReadError("Uma fonte documental não pode mais ser lida. Recarregue os documentos.") from None

    @property
    def inventory(self):
        return sorted({entry.source for entry in self.entries})

    def search(self, query: str, limit: int = 3) -> list[dict]:
        """Lexical retrieval used only for quotations, never for financial totals."""
        self.ensure_integrity()
        stop = {"que", "qual", "quais", "como", "para", "com", "dos", "das", "uma", "segundo", "materiais", "professor", "isso", "sobre", "onde", "pelo", "pela", "esse", "essa", "documentos", "fontes", "sustentam", "conclusao"}
        tokens = {t for t in re.findall(r"[a-z0-9]+", normalize(query)) if len(t) >= 3 and t not in stop}
        if not tokens:
            return []
        ranked = []
        for entry in self.entries:
            text = normalize(entry.excerpt)
            matching = [token for token in tokens if re.search(r"\b" + re.escape(token) + r"\b", text)]
            if not matching:
                continue
            # At least half of informative query terms must actually occur.
            if len(matching) / len(tokens) < 0.5:
                continue
            score = len(matching) * 4 + sum(text.count(token) for token in matching) / max(1, len(text) / 400)
            ranked.append((score, entry, matching))
        ranked.sort(key=lambda hit: (-hit[0], hit[1].source, hit[1].location))
        found = []
        for _, entry, tokens_found in ranked[:limit]:
            data = entry.to_dict()
            if len(data["excerpt"]) > 1500:
                text = normalize(data["excerpt"])
                offset = min(text.find(t) for t in tokens_found if text.find(t) >= 0)
                # Character offsets stay aligned for the material's Latin text.
                start = max(0, offset - 200)
                data["excerpt"] = ("…" if start else "") + data["excerpt"][start:start + 1500] + "…"
            found.append(data)
        if not found and self.errors:
            raise SourceReadError("Um ou mais documentos não puderam ser lidos. Revise a instalação de pypdf e os arquivos originais.")
        return found

    def concept(self, query: str) -> tuple[str | None, list[dict]]:
        """Answer a known definition only when its supporting passage is present."""
        self.ensure_integrity()
        question = normalize(query)
        definitions = [
            (("prejuizo", "saldo negativo", "liquido negativo", "credito acumulado"),
             "Líquido negativo = crédito acumulado", "enunciado_e_regras.md.pdf", "página 6"),
            (("cbs",), "CBS União substitui PIS, Cofins e, na prática, o IPI", "enunciado_e_regras.md.pdf", "página 3"),
            (("ibs",), "IBS estados e municípios substitui ICMS e ISS", "enunciado_e_regras.md.pdf", "página 3"),
            (("seletivo",), "Imposto Seletivo só sinalizado, sem cálculo", "enunciado_e_regras.md.pdf", "página 9"),
            (("uso e consumo", "credito amplo"), "todo o IBS/CBS calculado na compra, inclusive uso e consumo (crédito amplo)", "enunciado_e_regras.md.pdf", "página 5"),
            (("cclasstrib", "classificacao"), "O cClassTrib tem 6 dígitos", "enunciado_e_regras.md.pdf", "página 4"),
            (("imposto liquido",), "imposto líquido = débitos − créditos", "enunciado_e_regras.md.pdf", "página 6"),
        ]
        for markers, anchor, filename, location in definitions:
            if not any(marker in question for marker in markers):
                continue
            if anchor is None:
                return None, []
            entries = [e for e in self.entries if e.source == filename and e.location == location]
            if not entries and any(item["source"] == filename for item in self.errors):
                raise SourceReadError("O material necessário não pôde ser lido. Revise pypdf e o PDF original.")
            for entry in entries:
                offset = normalize(entry.excerpt).find(normalize(anchor))
                if offset < 0:
                    continue
                # Quote an actual passage, rather than generating textbook content.
                source = entry.to_dict()
                source["excerpt"] = entry.excerpt[max(0, offset - 100): min(len(entry.excerpt), offset + len(anchor) + 220)]
                if "prejuizo" in question or "negativo" in question or "credito acumulado" in question:
                    explanation = "Segundo o enunciado, saldo tributário líquido negativo representa crédito acumulado. Essa conta usa débitos das vendas menos créditos das compras; ela não demonstra prejuízo operacional. Não sei informar isso com os dados disponíveis. Para concluir lucro ou prejuízo da empresa, faltam receitas, custos e despesas suficientes. Crédito tributário não equivale a dinheiro recebido; os materiais não informam prazo de ressarcimento."
                elif "cbs" in markers:
                    explanation = "Segundo o enunciado, CBS é o tributo da União que substitui PIS, Cofins e, na prática, o IPI. Esta é a definição nos materiais congelados do desafio."
                elif "ibs" in markers:
                    explanation = "Segundo o enunciado, IBS é o tributo dos estados e municípios que substitui ICMS e ISS."
                elif "seletivo" in markers:
                    explanation = "No desafio, o Imposto Seletivo deve ser apenas sinalizado e fica fora do cálculo."
                elif "uso e consumo" in markers:
                    explanation = "Pela premissa do professor, todo o IBS/CBS calculado na compra gera crédito, inclusive nas compras para uso e consumo. A regra de hoje restringe os créditos à revenda. É crédito tributário, sem equivalência automática com lucro ou dinheiro recebido."
                elif "cclasstrib" in markers:
                    explanation = "O cClassTrib tem seis dígitos: os três primeiros identificam o CST; os três últimos, a hipótese específica. O enunciado manda considerar operação, NCM, descrição, destinatário e cadastro para classificar cada item."
                else:
                    explanation = "No desafio, imposto líquido = débitos das vendas − créditos das compras."
                return explanation, [source]
            return None, []
        return None, []
