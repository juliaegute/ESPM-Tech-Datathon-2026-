"""Read-only ingestion, coverage checks and source inventory.

All original strings are kept. There is deliberately no product identification
from free text or from the correction log, and no supplier inference from keys.
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
import unicodedata
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

SCENARIOS = ("hoje", "2027", "2033")
CENT = Decimal("0.01")
DIMENSIONS = ("cClassTrib", "perspectiva", "chave", "produto", "fornecedor", "destinatario", "finalidade")
ALIASES = {
    "produto": ("cProd", "produto", "descricao", "descricao_produto", "xProd"),
    "fornecedor": ("fornecedor", "nome_fornecedor", "emitente_nome", "razao_social_emitente"),
    "destinatario": ("destinatario", "nome_destinatario", "destinatario_nome"),
    "finalidade": ("finalidade", "finalidade_compra"),
    "NCM": ("NCM", "ncm"), "CFOP": ("CFOP", "cfop"),
}


class DataError(ValueError):
    """A data or tool limitation; never confused with an API failure."""
    def __init__(self, message, code="data_invalid"):
        super().__init__(message)
        self.code = code


def money(value) -> Decimal:
    """Parse exact nonnegative money without silently turning missing into zero."""
    if value is None or str(value).strip() == "":
        raise DataError("Valor monetário ausente; ausência não é zero.")
    try:
        result = Decimal(str(value).strip())
    except InvalidOperation as exc:
        raise DataError("Valor monetário inválido.") from exc
    if not result.is_finite() or result < 0:
        raise DataError("Valor monetário não finito ou negativo.")
    try:
        rounded = result.quantize(CENT, rounding=ROUND_HALF_UP)
    except InvalidOperation as exc:
        raise DataError("Valor monetário fora da precisão suportada.") from exc
    if result != rounded:
        raise DataError("Valor monetário com mais de duas casas decimais.")
    return rounded


def normalized(value: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", str(value).casefold()) if not unicodedata.combining(c)).strip()


def filter_value(field, value):
    text = normalized(value)
    if field == "finalidade" and text in {"uso_consumo", "uso consumo", "uso e consumo", "uso/consumo"}:
        return "uso e consumo"
    return text


def same_recorded_value(field, old, new):
    """Formatting is not a change in money. Raw files remain untouched."""
    if field == "vProd" or any(field == f"{s}_{name}" for s in SCENARIOS for name in ("imposto", "credito", "aliquota_efetiva_pct")):
        try:
            a, b = Decimal(old), Decimal(new)
            return a.is_finite() and b.is_finite() and a == b
        except InvalidOperation:
            pass
    return old == new


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def _key(row):
    return str(row.get("chave", "")).strip(), str(row.get("nItem", "")).strip()


class DataStore:
    def __init__(self, root: Path | str):
        self.root = Path(root).resolve()
        self.data_root = self.root / "data" if (self.root / "data").is_dir() else self.root
        self.project_root = self.root if (self.root / "docs").is_dir() else self.root.parent
        self.sources: list[dict] = []
        self.audit: dict = {"issues": [], "missing_files": [], "joins": {}, "blockers": []}
        self._paths = []
        self._find_sources()
        self.hashes = {str(p): sha256(p) for p in self._paths}
        self.rows: list[dict] = []
        self._load()
        self._validate()

    def _find_sources(self):
        if not self.data_root.exists():
            raise DataError(f"Pasta de dados não encontrada: {self.data_root}")
        for path in sorted(self.data_root.rglob("*")):
            if path.is_file() and not any(p.startswith(".") for p in path.relative_to(self.data_root).parts):
                self._paths.append(path)
                self.sources.append({"id": str(path.relative_to(self.data_root)), "path": str(path), "title": path.name, "available": True})

    def _one(self, name: str):
        matches = [p for p in self._paths if p.name == name]
        if len(matches) > 1:
            raise DataError(f"Mais de um arquivo {name}. Escolha uma única referência em data/complementares; nada foi sobrescrito.")
        return matches[0] if matches else None

    def _read_csv(self, path: Path):
        try:
            with path.open(encoding="utf-8-sig", newline="") as stream:
                head = stream.read(4096)
                header = head.splitlines()[0] if head else ""
                delimiter = ";" if header.count(";") > header.count(",") else ","
                stream.seek(0)
                reader = csv.DictReader(stream, delimiter=delimiter)
                if not reader.fieldnames or "chave" not in reader.fieldnames or "nItem" not in reader.fieldnames:
                    raise DataError(f"{path.name}: chave e nItem são obrigatórios.")
                if len(reader.fieldnames) != len(set(reader.fieldnames)):
                    raise DataError(f"{path.name}: cabeçalhos duplicados.")
                rows = []
                for line, row in enumerate(reader, 2):
                    if None in row:
                        raise DataError(f"{path.name}, linha {line}: número de campos incorreto.")
                    row = {k: str(v or "").strip() for k, v in row.items()}
                    row.update({"_source_path": str(path), "_line": str(line)})
                    rows.append(row)
                return rows
        except (UnicodeError, OSError, csv.Error) as exc:
            raise DataError(f"Erro na leitura de {path.name}: {type(exc).__name__}.") from exc

    def _note(self, code, message, count=None, **details):
        issue = {"code": code, "message": message, **details}
        if count is not None:
            issue["count"] = count
        self.audit["issues"].append(issue)

    def _block(self, message):
        self.audit["blockers"].append(message)
        if hasattr(self, "capabilities"):
            self.capabilities["analysis"] = False
            self.capabilities["projection_2033"] = False

    def _merge(self, additions, kind, fields=None):
        """Join on the composite key. Never collapse duplicate input rows."""
        existing = defaultdict(list)
        for row in self.rows:
            existing[_key(row)].append(row)
        incoming = defaultdict(list)
        for row in additions:
            incoming[_key(row)].append(row)
        duplicate_keys = [key for key, records in incoming.items() if len(records) > 1]
        if duplicate_keys:
            self._block(f"{kind}: {len(duplicate_keys)} chaves+nItem duplicadas; totais bloqueados.")
            self._note("duplicate_join", f"Duplicatas em {kind}; todos os registros de origem foram preservados.", len(duplicate_keys), examples=[list(x) for x in duplicate_keys[:10]])
        unmatched = [key for key in incoming if key not in existing]
        missing = [key for key in existing if key not in incoming]
        self.audit["joins"][kind] = {"matched": len(set(incoming) & set(existing)), "only_in_complement": len(unmatched), "missing_in_complement": len(missing), "duplicate_keys": len(duplicate_keys)}
        if unmatched or missing:
            self._note("coverage_divergence", f"Cobertura diferente em {kind}.", only_in_complement=len(unmatched), missing_in_complement=len(missing))
        if kind in ("v5_csv", "simulation") and (unmatched or missing):
            self._block(f"{kind}: cobertura incompleta ou divergente da referência; totais bloqueados.")
        if kind == "base_itens" and unmatched:
            self._block("base_itens possui itens sem simulação; totais empresariais bloqueados.")
        differences = 0
        by_field = Counter()
        examples = []
        representation_differences = 0
        for key, incoming_rows in incoming.items():
            for item in incoming_rows:
                selected_fields = fields or [k for k in item if not k.startswith("_") and k not in ("chave", "nItem")]
                if key not in existing:
                    new = dict(item)
                    new[f"_{kind}_source"] = f"{item['_source_path']}:{item['_line']}"
                    self.rows.append(new)
                    continue
                for row in existing[key]:
                    for field in selected_fields:
                        if field not in item:
                            continue
                        if row.get(field, "") and row[field] != item[field]:
                            if same_recorded_value(field, row[field], item[field]):
                                representation_differences += 1
                            else:
                                differences += 1
                                by_field[field] += 1
                                if len(examples) < 5:
                                    examples.append({"chave": key[0], "nItem": key[1], "field": field,
                                                     "previous": row[field], "selected": item[field]})
                        if kind == "base_itens" and field in ("perspectiva", "vProd") and row.get(field, ""):
                            continue
                        row[field] = item[field]
                    row[f"_{kind}_source"] = f"{item['_source_path']}:{item['_line']}"
        if differences:
            self._note("reference_difference", f"{kind} difere do consolidado; prioridade aplicada apenas em memória, originais preservados.", differences, fields=dict(by_field), examples=examples)
        if representation_differences:
            self._note("numeric_representation", f"{kind}: diferenças apenas de representação numérica, sem mudança de valor.", representation_differences)

    def _load(self):
        consolidated = self._one("base_completa_meridional.csv")
        classification = self._one("itens_classificados.csv")
        base_items = self._one("base_itens.csv")
        simulation = self._one("simulacao.json")
        if not any((consolidated, classification, base_items)):
            raise DataError("Nenhum CSV empresarial disponível: forneça base_completa_meridional.csv ou a referência v5 e base_itens.csv.")
        initial = consolidated or classification or base_items
        self.rows = self._read_csv(initial)
        for row in self.rows:
            row["_classification_source"] = f"{initial}:{row['_line']}"
            row["_simulation_source"] = f"{initial}:{row['_line']}"
        if base_items and base_items != initial:
            base_rows = self._read_csv(base_items)
            protected = {"chave", "nItem", "cClassTrib", "cClassTrib_simulacao", "status", "confianca", "imposto_seletivo", "fonte"}
            safe_fields = {k for r in base_rows for k in r if not k.startswith("_") and k not in protected and not any(k.startswith(s + "_") for s in SCENARIOS)}
            self._merge(base_rows, "base_itens", safe_fields)
        if classification and classification != initial:
            self._merge(self._read_csv(classification), "v5_csv", ("cClassTrib", "status", "confianca", "imposto_seletivo", "fonte"))
        if simulation:
            try:
                payload = json.loads(simulation.read_text(encoding="utf-8-sig"), parse_float=Decimal, parse_int=str)
                items = payload.get("itens")
                if not isinstance(items, list):
                    raise DataError("simulacao.json deve conter uma lista itens.")
                flat = []
                for index, item in enumerate(items):
                    row = {k: str(item.get(k, "")) for k in ("chave", "nItem", "perspectiva", "vProd")}
                    row["cClassTrib_simulacao"] = str(item.get("cClassTrib", ""))
                    for scenario in SCENARIOS:
                        scenario_data = item.get(scenario, {})
                        for name in ("imposto", "credito", "aliquota_efetiva_pct"):
                            value = scenario_data.get(name)
                            row[f"{scenario}_{name}"] = "" if value is None else str(value)
                    row.update({"_source_path": str(simulation), "_line": f"itens[{index}]"})
                    flat.append(row)
                self._merge(flat, "simulation")
                self._json_summary = payload.get("resumo", [])
            except (OSError, ValueError, TypeError, AttributeError) as exc:
                raise DataError(f"Erro na leitura da simulação JSON: {exc}") from exc
        self.reference_package = self._reference_package(classification, simulation)
        self.reference_name = ("Entrega Meridional v5 recebida — CSV final e JSON" if self.reference_package else
                               "CSV final e JSON complementares" if classification and simulation else "CSV consolidado fornecido (identidade v5 não comprovada)")
        self.audit["reference"] = self.reference_name
        self.audit["reference_package"] = self.reference_package
        for required, present in (("entrega_meridional_v5.zip ou CSV final + simulacao.json da v5", classification and simulation), ("base_itens.csv", base_items)):
            if not present:
                self.audit["missing_files"].append(required)
        has_original_catalog = any(p.name == "cadastro_empresas.csv" for p in self._paths)
        has_danfe = any(p.suffix.lower() == ".pdf" and "danfe" in str(p).casefold() for p in self._paths)
        if not (has_original_catalog and has_danfe):
            self.audit["missing_files"].append("ZIP com os dados originais (DANFEs, cadastros e tabelas)")
        self._normalize_dimensions()

    def _reference_package(self, classification, simulation):
        if not classification or not simulation:
            return None
        for manifest_path in self._paths:
            if manifest_path.name != "manifesto_importacao.json":
                continue
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                if manifest.get("arquivo") != "entrega_meridional_v5.zip":
                    continue
                archive = manifest_path.parent / "pacote_original.zip"
                expected = manifest.get("arquivos", {})
                relative_names = [str(p.relative_to(manifest_path.parent)) for p in (classification, simulation)]
                if sha256(archive) != manifest["sha256_zip"] or any(expected.get(n) != sha256(p) for n, p in zip(relative_names, (classification, simulation))):
                    self._block("Integridade do pacote v5 divergente do manifesto de importação.")
                    continue
                return {"file": manifest["arquivo"], "sha256": manifest["sha256_zip"], "integrity_ok": True,
                        "selection": "Pacote enviado pelo usuário como referência v5; autoria e acurácia não certificadas pelo aplicativo."}
            except (ValueError, OSError, KeyError):
                continue
        return None

    def _normalize_dimensions(self):
        for row in self.rows:
            for target, aliases in ALIASES.items():
                if target == "fornecedor" and row.get("perspectiva") != "compra":
                    continue
                if target == "destinatario" and row.get("perspectiva") != "venda":
                    continue
                if target == "produto" and row.get("cProd"):
                    row[target] = row["cProd"]
                elif not row.get(target):
                    for alias in aliases:
                        if row.get(alias):
                            row[target] = row[alias]
                            break
            if row.get("finalidade") and filter_value("finalidade", row["finalidade"]) == "uso e consumo":
                row["finalidade"] = "uso e consumo"

    def _validate(self):
        duplicate = Counter(_key(row) for row in self.rows)
        duplicates = [key for key, count in duplicate.items() if count > 1]
        if duplicates:
            self._block(f"{len(duplicates)} chaves+nItem duplicadas no conjunto; totais bloqueados.")
        bad = []
        class_mismatch = []
        recompute_mismatch = []
        for row in self.rows:
            reasons = []
            if not re.fullmatch(r"\d{44}", row.get("chave", "")):
                reasons.append("chave deve ter 44 dígitos")
            if not re.fullmatch(r"[1-9]\d*", row.get("nItem", "")):
                reasons.append("nItem deve ser inteiro positivo")
            if row.get("perspectiva") not in ("compra", "venda"):
                reasons.append("perspectiva ausente ou inválida")
            if not re.fullmatch(r"\d{6}", row.get("cClassTrib", "")):
                reasons.append("cClassTrib ausente ou inválido")
            if row.get("status") not in ("CLASSIFICADO", "REVISAR"):
                reasons.append("status ausente ou inválido")
            try:
                confidence = Decimal(row.get("confianca", ""))
                if not confidence.is_finite() or not 0 <= confidence <= 1:
                    raise InvalidOperation
            except InvalidOperation:
                reasons.append("confiança inválida")
            if row.get("imposto_seletivo") not in ("sim", "nao", "não"):
                reasons.append("sinalização de Imposto Seletivo inválida")
            try:
                money(row.get("vProd"))
                for scenario in SCENARIOS:
                    money(row.get(f"{scenario}_imposto"))
                    credit = row.get(f"{scenario}_credito", "")
                    if row.get("perspectiva") == "compra":
                        money(credit)
                    elif credit not in ("", None, "null"):
                        reasons.append(f"{scenario}: crédito de venda deve ser nulo")
            except DataError as exc:
                reasons.append(str(exc))
            if reasons:
                bad.append({"chave": row.get("chave"), "nItem": row.get("nItem"), "source": row.get("_source_path"), "line": row.get("_line"), "reasons": reasons})
            if row.get("cClassTrib_simulacao") and row.get("cClassTrib") != row["cClassTrib_simulacao"]:
                class_mismatch.append({"chave": row.get("chave"), "nItem": row.get("nItem"), "classification": row.get("cClassTrib"), "simulation": row["cClassTrib_simulacao"]})
        if bad:
            self._block(f"{len(bad)} itens com campos obrigatórios inválidos ou ausentes; totais bloqueados.")
        if class_mismatch:
            self._note("class_simulation_mismatch", "Classificação final e classe usada na simulação divergem. Resultados de referência preservados; projeção bloqueada nesses itens.", len(class_mismatch), examples=class_mismatch[:20])
        self.fields = [f for f in DIMENSIONS if any(row.get(f, "") for row in self.rows)]
        self.capabilities = {f: f in self.fields for f in (*DIMENSIONS, "NCM", "CFOP")}
        self.capabilities.update({"NCM": any(r.get("NCM") for r in self.rows), "CFOP": any(r.get("CFOP") for r in self.rows), "analysis": not self.audit["blockers"], "projection_2033": not self.audit["blockers"], "projection_2027": False, "verified_v5": False, "final_csv_loaded": self._one("itens_classificados.csv") is not None, "simulation_json_loaded": self._one("simulacao.json") is not None})
        self.capabilities["reference_package_loaded"] = bool(self.reference_package)
        self.filter_fields = self.fields + ["nItem", "status", "imposto_seletivo"] + [f for f in ("NCM", "CFOP") if self.capabilities[f]]
        self.audit.update({"rows": len(self.rows), "unique_items": len(duplicate), "documents": len({r.get("chave") for r in self.rows}), "duplicate_keys": len(duplicates), "invalid_rows": len(bad), "invalid_examples": bad[:30], "perspectivas": dict(Counter(r.get("perspectiva", "Ausente") for r in self.rows)), "status": dict(Counter(r.get("status", "Ausente") for r in self.rows)), "corrected_in_source": sum(r.get("corrigido") == "sim" for r in self.rows), "selective_tax_flags": sum(r.get("imposto_seletivo") == "sim" for r in self.rows), "class_simulation_divergences": len(class_mismatch), "available_dimensions": self.fields, "missing_dimensions": [f for f in DIMENSIONS if f not in self.fields]})
        # Source mentions are evidence of what was declared, not verification of absent files.
        mentioned = Counter()
        for row in self.rows:
            for filename in re.findall(r"[\w./-]+\.(?:xlsx|csv|pdf)", row.get("fonte", "")):
                if not any(p.name == Path(filename).name for p in self._paths):
                    mentioned[filename] += 1
        self.audit["unavailable_declared_sources_count"] = len(mentioned)
        self.audit["unavailable_declared_sources"] = [{"source": k, "mentions": v} for k, v in mentioned.most_common(25)]
        self.audit["unavailable_declared_sources_note"] = "Amostra de até 25 fontes ausentes mais citadas. As declarações completas são preservadas em fonte na exportação dos registros."
        self.audit["coverage_note"] = "Todos os registros dos arquivos disponíveis são processados. A identidade e a correção da referência v5 e sua equivalência com os cadastros originais não podem ser comprovadas apenas pelo nome dos arquivos."
        if self.reference_package:
            self.audit["coverage_note"] = "CSV final e JSON do pacote v5 recebido, associados à base de itens por chave+nItem. A auditoria confere cobertura e somas; DANFEs, tabelas e cadastros primários ainda ausentes não foram certificados."
        self.audit["entity_counts"] = {"products": len({r.get("cProd") or r.get("produto") for r in self.rows if r.get("cProd") or r.get("produto")}),
                                       "descriptions": len({r["descricao"] for r in self.rows if r.get("descricao")}),
                                       "suppliers": len({r["fornecedor"] for r in self.rows if r.get("fornecedor") and r["perspectiva"] == "compra"}),
                                       "recipients": len({r["destinatario"] for r in self.rows if r.get("destinatario") and r["perspectiva"] == "venda"})}
        ledger = self._one("correcoes_aplicadas.csv")
        self.audit["correction_history"] = {"consolidated_marked_items": self.audit["corrected_in_source"],
                                             "v5_ledger_rows": len(self._read_csv(ledger)) if ledger else None,
                                             "note": "Históricos de fontes distintas, preservados sem aplicar novas correções. A classificação vigente vem do CSV final."}
        self._validate_recalculation()
        self._validate_summary()

    def _validate_summary(self):
        summary = getattr(self, "_json_summary", None)
        if summary is None:
            return
        if not summary:
            self._note("summary_missing", "JSON sem resumo verificável; totais calculados integralmente dos itens.")
            return
        if not isinstance(summary, list):
            self._block("Resumo JSON não é uma lista; conflito de referência.")
            return
        differences = []
        for scenario in SCENARIOS:
            candidates = [r for r in summary if isinstance(r, dict) and str(r.get("cenario")) == scenario]
            if len(candidates) != 1:
                differences.append({"scenario": scenario, "reason": "cenário ausente ou duplicado no resumo"})
                continue
            try:
                debits = sum((money(r.get(f"{scenario}_imposto")) for r in self.rows if r.get("perspectiva") == "venda"), Decimal(0))
                credits = sum((money(r.get(f"{scenario}_credito")) for r in self.rows if r.get("perspectiva") == "compra"), Decimal(0))
                for name, expected in (("debitos_vendas", debits), ("creditos_compras", credits), ("imposto_liquido", debits - credits)):
                    raw = candidates[0].get(name)
                    actual = Decimal(str(raw))
                    if not actual.is_finite() or actual != expected:
                        differences.append({"scenario": scenario, "field": name, "recorded": str(raw), "computed": str(expected)})
            except (DataError, InvalidOperation):
                differences.append({"scenario": scenario, "reason": "campo monetário ausente ou inválido"})
        self.audit["json_summary_check"] = {"ok": not differences, "differences": differences}
        if differences:
            self._block("Resumo JSON diverge da soma dos itens ou está incompleto; totais bloqueados até revisão.")
            self.capabilities["analysis"] = False
            self.capabilities["projection_2033"] = False

    def _validate_recalculation(self):
        factors = {"000001": Decimal(1), "200034": Decimal("0.4"), "200030": Decimal("0.4"), "200003": Decimal(0), "200014": Decimal(0), "200005": Decimal(0), "410001": Decimal(0), "410004": Decimal(0)}
        compared = 0
        differences = []
        credit_differences = []
        for row in self.rows:
            factor = factors.get(row.get("cClassTrib_simulacao") or row.get("cClassTrib"))
            if factor is None:
                continue
            try:
                value = money(row.get("vProd"))
                expected = sum(((value * rate * factor).quantize(CENT, rounding=ROUND_HALF_UP) for rate in (Decimal(".088"), Decimal(".177"))), Decimal(0))
                actual = money(row.get("2033_imposto"))
            except DataError:
                continue
            compared += 1
            if expected != actual:
                differences.append({"chave": row.get("chave"), "nItem": row.get("nItem"), "recorded": str(actual), "recomputed": str(expected)})
            if row.get("perspectiva") == "compra":
                try:
                    recorded_credit = money(row.get("2033_credito"))
                    if recorded_credit != expected:
                        credit_differences.append({"chave": row.get("chave"), "nItem": row.get("nItem"), "recorded": str(recorded_credit), "recomputed": str(expected)})
                except DataError:
                    pass  # Missing/invalid credit already blocks totals in validation.
        self.audit["recalculation_2033"] = {"compared": compared, "differences": len(differences), "examples": differences[:20], "credit_differences": len(credit_differences), "credit_examples": credit_differences[:20], "rounding": "CBS e IBS separados por item, Decimal ROUND_HALF_UP"}
        if differences:
            self._note("recalculation_difference", "Divergência entre valor registrado e recálculo pelas premissas do professor. Originais e resultados de referência preservados.", len(differences))
        if credit_differences:
            self._note("credit_recalculation_difference", "Crédito registrado diverge do IBS/CBS calculado em 2033. Referência preservada e projeção bloqueada nos itens afetados.", len(credit_differences))

    def verify_originals(self) -> dict:
        changed = [path for path, expected in self.hashes.items() if not Path(path).is_file() or sha256(Path(path)) != expected]
        return {"ok": not changed, "checked": len(self.hashes), "changed": changed}

    def validate_filters(self, filters: dict | None):
        if filters is None:
            return {}
        if not isinstance(filters, dict):
            raise DataError("Filtros devem ser um objeto de campos e valores.")
        allowed = set(DIMENSIONS) | {"nItem", "status", "imposto_seletivo", "NCM", "CFOP"}
        for field, value in filters.items():
            if field not in allowed:
                raise DataError(f"Filtro não suportado: {field}.")
            if field in DIMENSIONS and field not in self.fields:
                raise DataError(f"Não sei informar isso com os dados disponíveis. O campo {field} está ausente; envie base_itens.csv e os cadastros originais.", code="missing_field")
            if field in ("NCM", "CFOP") and not self.capabilities[field]:
                raise DataError(f"Não sei informar isso com os dados disponíveis. O campo {field} está ausente.", code="missing_field")
            values = value if isinstance(value, list) else [value]
            if not values or len(values) > 1000 or not all(isinstance(v, (str, int)) and not isinstance(v, bool) and len(str(v)) <= 300 for v in values):
                raise DataError(f"Valor de filtro inválido: {field}.")
        return dict(filters)

    def filter_rows(self, filters: dict | None = None) -> list[dict]:
        filters = self.validate_filters(filters)
        result = self.rows
        for field, value in filters.items():
            values = value if isinstance(value, list) else [value]
            requested = {filter_value(field, v) for v in values}
            result = [row for row in result if filter_value(field, row.get(field, "")) in requested and not (field in ("fornecedor", "finalidade") and row.get("perspectiva") == "venda") and not (field == "destinatario" and row.get("perspectiva") == "compra")]
        return result

    def lookup(self, term: str, field: str = "produto") -> list[dict]:
        self.validate_filters({field: term})
        needle = normalized(term)
        if not needle:
            return []
        applicable = [row for row in self.rows if not (field in ("fornecedor", "finalidade") and row.get("perspectiva") != "compra") and not (field == "destinatario" and row.get("perspectiva") != "venda")]
        extra_fields = {"produto": ("descricao", "cProd"), "fornecedor": ("emitente_id",), "destinatario": ("destinatario_id",)}.get(field, ())
        return self._distinct([row for row in applicable if any(needle in normalized(row.get(name, "")) for name in (field, *extra_fields))], field)

    @staticmethod
    def _distinct(rows, field):
        counts = Counter(row.get(field, "") for row in rows)
        return [{"value": label, "count": count} for label, count in sorted(counts.items())]
