"""Deterministic, allowlisted financial tools. No eval, code or free-form SQL."""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from .data import CENT, SCENARIOS, DataError, DataStore, money

ZERO = Decimal("0.00")
FACTORS = {"000001": Decimal(1), "200034": Decimal("0.4"), "200030": Decimal("0.4"), "200003": ZERO, "200014": ZERO, "200005": ZERO, "410001": ZERO, "410004": ZERO}
METRICS = ("gain", "creditos", "debitos", "valor_compras", "valor_vendas", "purchase_effect", "sales_effect")


def fmt(value: Decimal) -> str:
    return format(value.quantize(CENT, rounding=ROUND_HALF_UP), ".2f")


class Engine:
    def __init__(self, store: DataStore):
        self.store = store

    def _scenario(self, scenario):
        scenario = str(scenario)
        if scenario not in SCENARIOS:
            raise DataError("Cenário inválido. Escolha hoje, 2027 ou 2033.", code="invalid_parameters")
        return scenario

    def _rows(self, filters):
        rows = self.store.filter_rows(filters)
        if not rows:
            raise DataError("Nenhum registro corresponde ao recorte no arquivo disponível. Essa busca sem resultados não comprova que o registro ou fornecedor não exista.", code="no_matches")
        return rows

    def _ready(self):
        if self.store.audit["blockers"]:
            raise DataError("Erro de qualidade dos dados: " + " ".join(self.store.audit["blockers"]))
        self._integrity()

    def _integrity(self):
        integrity = self.store.verify_originals()
        if not integrity["ok"]:
            raise DataError("Os arquivos de origem mudaram após a leitura. Recarregue os dados antes de calcular.")

    def _group(self, row, group_by):
        if group_by in ("fornecedor", "finalidade") and row.get("perspectiva") == "venda":
            return "Não se aplica — vendas"
        if group_by == "destinatario" and row.get("perspectiva") == "compra":
            return "Não se aplica — compras"
        return row.get(group_by) or "Não informado"

    @staticmethod
    def _totals(rows, scenario):
        debits = sum((money(r[f"{scenario}_imposto"]) for r in rows if r["perspectiva"] == "venda"), ZERO)
        credits = sum((money(r[f"{scenario}_credito"]) for r in rows if r["perspectiva"] == "compra"), ZERO)
        return {"debitos": fmt(debits), "creditos": fmt(credits), "liquido": fmt(debits - credits)}

    @staticmethod
    def _effects(row, scenario):
        if row["perspectiva"] == "venda":
            return money(row["hoje_imposto"]) - money(row[f"{scenario}_imposto"]), ZERO
        return ZERO, money(row[f"{scenario}_credito"]) - money(row["hoje_credito"])

    def _evidence(self, rows):
        paths = defaultdict(list)
        for row in rows:
            source = row.get("_simulation_source")
            path, line = source.rsplit(":", 1) if source else (row.get("_source_path", ""), row.get("_line", ""))
            paths[path].append(line)
        evidence = []
        for path, lines in paths.items():
            evidence.append({"type": "data", "path": path, "source": path.rsplit("/", 1)[-1], "record_count": len(lines), "first_line": lines[0], "claim": "Registros integralmente processados no recorte; use a exportação para consultar todas as linhas."})
        complement_paths = {}
        for row in rows:
            for tag in ("_simulation_source", "_v5_csv_source", "_base_itens_source"):
                if row.get(tag):
                    path, line = row[tag].rsplit(":", 1)
                    if path not in paths:
                        complement_paths[path] = line
        for path, line in complement_paths.items():
            evidence.append({"type": "data", "path": path, "source": path.rsplit("/", 1)[-1], "first_line": line, "claim": "Arquivo complementar associado por chave+nItem, conforme auditoria de cobertura."})
        doc = self.store.project_root / "docs" / "enunciado_e_regras.md.txt"
        if doc.is_file():
            original = next((s["path"] for s in self.store.sources if s["title"] == "enunciado_e_regras.md.pdf"), None)
            evidence.append({"type": "professor", "path": str(doc), "original_path": original, "source": "enunciado_e_regras.md.pdf" if original else doc.name, "section": "Seção 5, páginas 5–6", "claim": "Imposto líquido = débitos das vendas − créditos das compras; saldo negativo = crédito acumulado. CBS e IBS arredondados separadamente por item."})
        return evidence

    def _analyze_rows(self, rows, scenario, filters, group_by, metric="gain"):
        if metric not in METRICS:
            raise DataError(f"Métrica não suportada: {metric}.", code="invalid_parameters")
        totals = {s: self._totals(rows, s) for s in SCENARIOS}
        measure_names = ("creditos_hoje", "creditos_cenario", "debitos_hoje", "debitos_cenario", "valor_compras", "valor_vendas")
        groups = defaultdict(lambda: {"sales": ZERO, "purchases": ZERO, "count": 0, **{name: ZERO for name in measure_names}})
        for row in rows:
            sales, purchases = self._effects(row, scenario)
            group = groups[self._group(row, group_by)]
            group["sales"] += sales
            group["purchases"] += purchases
            group["count"] += 1
            if group_by == "produto" and row.get("descricao"):
                group.setdefault("descriptions", set()).add(row["descricao"])
            if row["perspectiva"] == "compra":
                group["creditos_hoje"] += money(row["hoje_credito"])
                group["creditos_cenario"] += money(row[f"{scenario}_credito"])
                group["valor_compras"] += money(row["vProd"])
            else:
                group["debitos_hoje"] += money(row["hoje_imposto"])
                group["debitos_cenario"] += money(row[f"{scenario}_imposto"])
                group["valor_vendas"] += money(row["vProd"])
        ranking = [{"label": label, "gain": fmt(v["sales"] + v["purchases"]), "sales_effect": fmt(v["sales"]), "purchase_effect": fmt(v["purchases"]), "count": v["count"], **{name: fmt(v[name]) for name in measure_names}, "aumento_creditos": fmt(v["purchases"]), "reducao_debitos": fmt(v["sales"])} for label, v in groups.items()]
        ranking.sort(key=lambda r: (-Decimal(r["gain"]), r["label"]))
        if group_by == "produto":
            for entry in ranking:
                descriptions = sorted(groups[entry["label"]].get("descriptions", set()))
                entry["descriptions"] = descriptions
                entry["display_label"] = entry["label"] + (" · " + descriptions[0] if len(descriptions) == 1 else f" · {len(descriptions)} descrições registradas" if descriptions else "")
        metric_field = {"creditos": "creditos_cenario", "debitos": "debitos_cenario"}.get(metric, metric)
        metric_ranking = [{**entry, "value": entry[metric_field]} for entry in ranking]
        metric_ranking.sort(key=lambda r: (-Decimal(r["value"]), r["label"]))
        metric_total = sum((Decimal(entry["value"]) for entry in metric_ranking), ZERO)
        sales = sum((g["sales"] for g in groups.values()), ZERO)
        purchases = sum((g["purchases"] for g in groups.values()), ZERO)
        gain = Decimal(totals["hoje"]["liquido"]) - Decimal(totals[scenario]["liquido"])
        if gain != sales + purchases:
            raise DataError("Falha de reconciliação interna; análise interrompida.")
        dimension_coverage = {}
        for dimension in ("produto", "fornecedor", "destinatario", "finalidade"):
            applicable = [r for r in self.store.rows if not (dimension in ("fornecedor", "finalidade") and r["perspectiva"] == "venda") and not (dimension in ("destinatario",) and r["perspectiva"] == "compra")]
            missing = sum(not r.get(dimension) for r in applicable)
            dimension_coverage[dimension] = {"applicable_records": len(applicable), "missing_records": missing, "complete": missing == 0}
        coverage_warnings = [f"O cadastro de {field} não cobre {dimension_coverage[field]['missing_records']} registros aplicáveis; o recorte considera somente as associações disponíveis e pode não representar todo o {field}." for field in (filters or {}) if field in dimension_coverage and not dimension_coverage[field]["complete"]]
        return {
            "scenario": scenario, "filters": dict(filters or {}), "group_by": group_by, "count": len(rows),
            "coverage": {"selected_rows": len(rows), "available_rows": len(self.store.rows), "all_available_records": len(rows) == len(self.store.rows), "company_completeness_verified": bool(self.store.capabilities["verified_v5"] and not self.store.audit["missing_files"]), "reference_coverage_verified": bool(self.store.capabilities.get("reference_package_loaded") and not self.store.audit["blockers"] and all(not j["only_in_complement"] and not j["missing_in_complement"] and not j["duplicate_keys"] for j in self.store.audit["joins"].values())), "reference": self.store.reference_name, "note": self.store.audit["coverage_note"], "dimension_coverage": dimension_coverage, "warnings": coverage_warnings},
            "totals": totals, "gain": fmt(gain), "sales_effect": fmt(sales), "purchase_effect": fmt(purchases),
            "metric": metric, "metric_total": fmt(metric_total), "metric_ranking": metric_ranking,
            "value_totals": {name: fmt(sum((g[name] for g in groups.values()), ZERO)) for name in ("valor_compras", "valor_vendas")},
            "ranking": ranking, "positive_ranking": [r for r in ranking if Decimal(r["gain"]) > 0], "negative_ranking": sorted([r for r in ranking if Decimal(r["gain"]) < 0], key=lambda r: Decimal(r["gain"])),
            "reconciliation": {"ok": True, "ranking_sum": fmt(sum((Decimal(r["gain"]) for r in ranking), ZERO)), "formula": "ganho = líquido hoje − líquido cenário = efeito vendas + efeito compras", "grouping_note": "Fornecedores nas vendas: não se aplica. Destinatários nas compras: não se aplica. Valores sem cadastro ficam em Não informado; nenhuma linha é descartada."},
            "best_scenario": min(SCENARIOS, key=lambda s: Decimal(totals[s]["liquido"])),
            "largest_net_tax_scenario": max(SCENARIOS, key=lambda s: Decimal(totals[s]["liquido"])),
            "evidence": self._evidence(rows),
            "limitations": ["Crédito tributário não é lucro nem dinheiro recebido; saldo líquido negativo representa crédito acumulado no desafio."] + (["Referência v5 recebida e somas conferidas; documentos primários e acurácia das classificações ainda não certificados."] if self.store.capabilities.get("reference_package_loaded") else ["A equivalência com a referência v5 não foi comprovada."]) + coverage_warnings,
        }

    def analyze(self, scenario="2033", filters=None, group_by="cClassTrib", metric="gain"):
        scenario = self._scenario(scenario)
        self._ready()
        if group_by not in self.store.fields:
            raise DataError(f"Não sei informar isso com os dados disponíveis. O agrupamento {group_by} não está disponível; faltam os respectivos cadastros.", code="missing_field")
        filters = self.store.validate_filters(filters)
        rows = self._rows(filters)
        return self._analyze_rows(rows, scenario, filters, group_by, metric)

    def records(self, filters=None):
        """Export all supporting rows, not just the ranking or retrieval sample."""
        self._integrity()
        rows = self._rows(filters)
        return [dict(row) for row in rows]

    def classification(self, filters=None):
        self._integrity()
        rows = self._rows(filters)
        items = []
        for row in rows:
            items.append({k: row.get(k, "") for k in ("chave", "nItem", "produto", "NCM", "CFOP", "cClassTrib", "cClassTrib_simulacao", "status", "confianca", "imposto_seletivo", "fonte", "corrigido", "correcao_fonte_nova")})
            items[-1]["source"] = row.get("_v5_csv_source") or row.get("_classification_source") or f"{row['_source_path']}:{row['_line']}"
            items[-1]["evidence_status"] = "Classificação registrada no CSV. A justificativa textual é uma declaração de origem, não a validação de arquivos ausentes."
        return {"count": len(rows), "items": items, "evidence": self._evidence(rows), "limitations": ["DANFEs, tabelas e cadastros citados mas não anexados não podem ser consultados nem ter seu conteúdo confirmado.", "Nenhuma classificação ou correção foi criada pelo aplicativo."]}

    def project(self, scenario="2033", filters=None, target="compra", percent="10", basis="valor", mode="preco", confirmed=False):
        scenario = self._scenario(scenario)
        self._ready()
        if not confirmed:
            raise DataError("Confirme a hipótese: alterar o valor de cada item por variação de preço, mantendo quantidades, mix, classificações e demais operações constantes?", code="ambiguous_projection")
        if basis != "valor" or mode not in ("preco", "valor_proporcional"):
            raise DataError("A ferramenta disponível altera proporcionalmente o valor dos itens. Mudanças de quantidade ou mix não estão implementadas nesta ferramenta.", code="projection_unavailable")
        if target not in ("compra", "venda"):
            raise DataError("Alvo inválido; escolha compra ou venda.")
        if scenario != "2033":
            raise DataError("A ferramenta de projeção implementada recalcula 2033. O recálculo hipotético de hoje e 2027 ainda não está implementado e validado por componente; os resultados originais desses cenários permanecem consultáveis.", code="projection_unavailable")
        try:
            pct = Decimal(str(percent))
        except InvalidOperation as exc:
            raise DataError("Percentual inválido.") from exc
        if not pct.is_finite() or pct < -100 or pct > 1000:
            raise DataError("Percentual deve estar entre −100% e 1.000%.")
        filters = self.store.validate_filters(filters)
        rows = self._rows(filters)
        changed = [r for r in rows if r["perspectiva"] == target]
        if not changed:
            raise DataError("O recorte não possui operações do tipo solicitado; a projeção não foi calculada.")
        for row in changed:
            if row.get("cClassTrib_simulacao") and row["cClassTrib_simulacao"] != row["cClassTrib"]:
                raise DataError("Classificação final e de simulação divergem neste recorte; projeção bloqueada até revisão autorizada.")
            if row["cClassTrib"] not in FACTORS:
                raise DataError("A redução da classe não está nas premissas disponíveis; não é possível projetar.")
            factor = FACTORS[row["cClassTrib"]]
            value = money(row["vProd"])
            calculated = sum(((value * rate * factor).quantize(CENT, rounding=ROUND_HALF_UP) for rate in (Decimal(".088"), Decimal(".177"))), ZERO)
            if money(row["2033_imposto"]) != calculated or (target == "compra" and money(row["2033_credito"]) != calculated):
                raise DataError("Os resultados de referência deste item divergem do recálculo pelas premissas do professor. A projeção está bloqueada até revisão autorizada, preservando a referência.", code="projection_unavailable")
        hypothetical = deepcopy(rows)
        multiplier = Decimal(1) + pct / 100
        before = ZERO
        after = ZERO
        for row in hypothetical:
            if row["perspectiva"] != target:
                continue
            original_value = money(row["vProd"])
            new_value = (original_value * multiplier).quantize(CENT, rounding=ROUND_HALF_UP)
            before += original_value
            after += new_value
            factor = FACTORS[row["cClassTrib"]]
            cbs = (new_value * Decimal(".088") * factor).quantize(CENT, rounding=ROUND_HALF_UP)
            ibs = (new_value * Decimal(".177") * factor).quantize(CENT, rounding=ROUND_HALF_UP)
            row["vProd"] = fmt(new_value)
            row["2033_imposto"] = fmt(cbs + ibs)
            if target == "compra":
                row["2033_credito"] = fmt(cbs + ibs)
        reference = self._analyze_rows(rows, scenario, filters, "cClassTrib")
        projected = self._analyze_rows(hypothetical, scenario, filters, "cClassTrib")
        impact = Decimal(projected["totals"][scenario]["liquido"]) - Decimal(reference["totals"][scenario]["liquido"])
        change_description = "por preço" if mode == "preco" else "por escala proporcional do valor monetário de cada item; sem inferir quantidade ou preço unitário"
        return {"kind": "user_hypothesis", "label": "Simulação hipotética do usuário; referência original preservada", "scenario": scenario, "filters": dict(filters), "assumptions": {"target": target, "percent": str(pct), "basis": basis, "mode": mode, "confirmed": True, "changed_parameter": f"Valor de cada item de {target}: {pct}% {change_description}", "constants": "Mix, classificações, operações fora do alvo e valores do cenário hoje constantes. Sem hipóteses de demanda, custo, crescimento ou prazo de crédito." + (" Quantidades constantes por hipótese explícita de preço." if mode == "preco" else " Sem inferir variação física de quantidades."), "rounding": "Novo vProd por item com duas casas; CBS e IBS calculados e arredondados separadamente, Decimal ROUND_HALF_UP", "base_value_before": fmt(before), "base_value_after": fmt(after), "affected_rows": len(changed)}, "reference": reference, "hypothetical": projected, "change_in_net_tax": fmt(impact), "reduction_vs_reference": fmt(-impact), "gain_vs_hoje": projected["gain"], "evidence": reference["evidence"], "limitations": ["Menor imposto líquido não é recomendação de comprar mais; a hipótese não estima lucro, caixa ou prazo de ressarcimento."]}
