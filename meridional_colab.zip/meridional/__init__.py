"""Meridional: conversa fundamentada, cálculos locais e evidências preservadas."""

__version__ = "1.0.0"
