"""Private, session-isolated Gradio interface backed by the Python engine.

The launch policy is deliberately left to the entry point: this module never
creates a public tunnel or uploads a dataset. Exports are derived copies in a
session-specific temporary directory, never edits to the original inputs.
"""
from __future__ import annotations

import csv
from dataclasses import asdict, dataclass, field, is_dataclass
from decimal import Decimal, InvalidOperation
import html
import json
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any

import gradio as gr
import plotly.graph_objects as go

from .data import DataStore
from .engine import Engine
from .sources import SourceBook
from .conversation import Conversation, LocalProvider, OpenAIProvider


_FIELD_LABELS = {
    "cClassTrib": "Classificação tributária",
    "perspectiva": "Compras e vendas",
    "chave": "Documento · chave",
    "produto": "Produto",
    "fornecedor": "Fornecedor",
    "destinatario": "Destinatário",
    "finalidade": "Finalidade",
    "NCM": "NCM",
    "CFOP": "CFOP",
}
_SCENARIOS = [("Referência de hoje", "hoje"), ("Transição · 2027", "2027"), ("Cenário · 2033", "2033")]
_SUGGESTIONS = [
    "Onde tenho o maior ganho tributário em 2033?",
    "O resultado vem das vendas ou dos créditos nas compras?",
    "O que é CBS segundo os materiais do professor?",
]

CSS = """
.gradio-container {width:100% !important; min-width:0 !important; max-width:1240px !important; margin:auto; font-family:Inter,system-ui,sans-serif; --block-label-text-color:#086b66; --link-text-color:#086b66;}
.gradio-container main {width:100%; min-width:0;}
body {background:#f4f7fb;}
#hero {padding:16px 2px 5px;}
#hero .eyebrow {font-size:11px; font-weight:800; letter-spacing:1.7px; color:#087f8c;}
#hero h1 {font-size:32px; letter-spacing:-1.1px; line-height:1.15; margin:7px 0; color:#152d44;}
#hero p {font-size:15px; color:#4b6076; margin:8px 0;}
#privacy-note {font-size:12px; color:#52677d; border-left:3px solid #14a89e; padding:8px 12px; background:#eef9f7;}
#conversation-panel {border:1px solid #dce5ef; border-radius:18px; padding:18px; background:white; box-shadow:0 8px 30px #21354708;}
#question-input textarea {font-size:16px !important; min-height:66px !important;}
#send-button {min-height:74px; font-weight:750; background:#087f79 !important; color:#fff !important;}
.gradio-container button[role="tab"][aria-selected="true"] {color:#086b66 !important;}
#chat-history {border-radius:12px;}
.suggestion {font-size:12px !important; min-height:42px;}
#active-context {background:#edf3f9; border-radius:10px; padding:10px 14px; font-size:13px;}
.metric-grid {display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:14px; margin:12px 0;}
.metric-card {background:white; border:1px solid #dce5ef; border-radius:14px; padding:18px;}
.metric-card .label {font-size:12px; color:#52677d; font-weight:650;}
.metric-card .value {font-size:25px; color:#142d44; font-weight:800; letter-spacing:-.7px; margin-top:6px;}
.metric-card .hint {font-size:11px; color:#52677d; margin-top:5px;}
.source-card {padding:12px 0; border-bottom:1px solid #e1e8f0;}
.empty-panel {padding:20px; border:1px dashed #c6d4e3; color:#52677d; border-radius:12px;}
@media (max-width:680px) {.metric-grid {grid-template-columns:1fr;} #hero h1 {font-size:26px;} #conversation-panel {padding:10px;} .metric-card .value {font-size:23px;}}
"""


def _plain(value):
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, dict):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_plain(v) for v in value]
    if isinstance(value, (Decimal, Path)):
        return str(value)
    return value


def _brl(value):
    if value is None:
        return "Indisponível"
    try:
        number = Decimal(str(value))
        text = f"{abs(number):,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")
        return ("− " if number < 0 else "") + "R$ " + text
    except (InvalidOperation, ValueError, TypeError):
        return "Indisponível"


def _safe_csv(value):
    """Prevent spreadsheet formula execution while preserving real numbers."""
    text = "" if value is None else str(value)
    candidate = text.lstrip(" \r\n\t")
    if candidate.startswith(("=", "+", "-", "@")):
        try:
            Decimal(candidate)
        except InvalidOperation:
            return "'" + text
    if text.startswith(("\t", "\r", "\n")):
        return "'" + text
    return text


def _records_table(records):
    records = [_plain(row) for row in records[:25] if isinstance(row, dict) or is_dataclass(row)]
    if not records:
        return {"headers": ["Registros"], "data": []}
    headers = list(dict.fromkeys(key for row in records for key in row))
    return {"headers": headers, "data": [[str(row.get(key, "")) for key in headers] for row in records]}


def _scenario_table(analysis):
    headers = ["Cenário", "Débitos das vendas", "Créditos das compras", "Imposto líquido"]
    if not analysis:
        return {"headers": headers, "data": []}
    views = [("Referência · ", analysis["reference"]), ("Hipótese · ", analysis["hypothetical"])] if "hypothetical" in analysis else [("", analysis)]
    return {"headers": headers, "data": [
        [prefix + ("Hoje" if scenario == "hoje" else scenario),
         _brl(values.get("debitos")), _brl(values.get("creditos")), _brl(values.get("liquido"))]
        for prefix, view in views for scenario, values in view.get("totals", {}).items()
    ]}


def _metrics(analysis):
    if not analysis:
        return '<div class="empty-panel">Os indicadores aparecerão quando houver uma análise válida. A ausência de dados não é tratada como zero.</div>'
    is_hypothesis = "hypothetical" in analysis
    envelope = analysis
    analysis = analysis.get("hypothetical", analysis)
    cards = [
        ("Ganho tributário simulado", analysis.get("gain"), "Hoje menos o cenário ativo"),
        ("Contribuição das vendas", analysis.get("sales_effect"), "Imposto de hoje menos o do cenário"),
        ("Contribuição das compras", analysis.get("purchase_effect"), "Crédito do cenário menos o de hoje"),
    ]
    heading = ""
    if is_hypothesis:
        assumptions = envelope.get("assumptions", {})
        heading = ('<div class="empty-panel"><strong>HIPÓTESE DO USUÁRIO · referência preservada</strong><br>' +
                   html.escape(str(assumptions.get("changed_parameter", ""))) + '<br>' +
                   html.escape(str(assumptions.get("constants", ""))) + '<br>' +
                   'Redução do imposto líquido em relação à referência do mesmo cenário: ' +
                   html.escape(_brl(envelope.get("reduction_vs_reference"))) + '</div>')
    return heading + '<div class="metric-grid">' + "".join(
        '<div class="metric-card"><div class="label">' + html.escape(title) +
        '</div><div class="value">' + html.escape(_brl(value)) +
        '</div><div class="hint">' + html.escape(hint) + '</div></div>'
        for title, value, hint in cards
    ) + '</div>'


def _chart(analysis, positive=True):
    if analysis:
        analysis = analysis.get("hypothetical", analysis)
    rows = (analysis or {}).get("ranking", [])
    selected = []
    for row in rows:
        try:
            amount = Decimal(str(row["gain"]))
        except (InvalidOperation, KeyError, ValueError, TypeError):
            continue
        if amount > 0 if positive else amount < 0:
            selected.append((row, amount))
    selected.sort(key=lambda pair: pair[1], reverse=positive)
    selected = selected[:10]
    title = "Maiores contribuições positivas" if positive else "Maiores contribuições negativas"
    figure = go.Figure()
    if selected:
        selected.reverse()
        figure.add_bar(
            x=[float(value) for _, value in selected],
            y=[str(row.get("display_label", row.get("label", "Sem identificação"))) for row, _ in selected],
            orientation="h", marker_color="#0a9c91" if positive else "#df6d44",
            customdata=[[_brl(value), row.get("count", "")] for row, value in selected],
            hovertemplate="%{y}<br>%{customdata[0]}<br>%{customdata[1]} itens<extra></extra>",
        )
    else:
        figure.add_annotation(text="Sem contribuições positivas neste recorte" if positive else "Sem contribuições negativas neste recorte",
                              x=.5, y=.5, xref="paper", yref="paper", showarrow=False, font={"color": "#52677d"})
    figure.update_layout(title={"text": title, "font": {"size": 16}}, height=350,
                         paper_bgcolor="white", plot_bgcolor="white", margin={"l": 8, "r": 15, "t": 50, "b": 45},
                         font={"family": "Inter, Arial, sans-serif", "color": "#29445e"},
                         xaxis={"title": "Contribuição (R$)", "gridcolor": "#edf2f7", "zerolinecolor": "#bdccdc"},
                         yaxis={"automargin": True}, showlegend=False)
    return figure


def _source_markdown(evidence):
    if not evidence:
        return "Ainda não há fontes selecionadas para uma resposta. Faça uma pergunta ou abra a auditoria dos arquivos carregados."
    parts = []
    for index, entry in enumerate(evidence, 1):
        entry = _plain(entry)
        if not isinstance(entry, dict):
            continue
        source = html.escape(str(entry.get("source", entry.get("file", "Fonte sem identificação"))))
        fallback_location = entry.get("section", "") or ("a partir da linha " + str(entry["first_line"]) if entry.get("first_line") else "")
        location = html.escape(str(entry.get("location", fallback_location)))
        excerpt = html.escape(str(entry.get("excerpt", entry.get("claim", entry.get("description", "")))))
        available = "Fonte disponível" if entry.get("available", True) else "Fonte indisponível — não comprova a afirmação"
        parts.append(f"**[{index}] {source}** · {location}\n\n{excerpt}\n\n*{available}*")
    return "\n\n---\n\n".join(parts) or "Nenhuma fonte verificável foi retornada."


@dataclass
class _Session:
    conversation: Any
    directory: str
    mode: str = "Chave ausente"
    messages: list = field(default_factory=list)
    analysis: dict | None = None
    evidence: list = field(default_factory=list)
    records: list = field(default_factory=list)
    busy: bool = False
    notice: str = ""


def _cleanup(session):
    if isinstance(session, _Session) and Path(session.directory).name.startswith("meridional-session-"):
        shutil.rmtree(session.directory, ignore_errors=True)


def build_app(data_dir=None, *, default_local=False) -> gr.Blocks:
    """Build a real Python-connected app; call launch(share=False) separately."""
    root = Path(data_dir).resolve() if data_dir else Path(__file__).resolve().parent.parent
    store = DataStore(root)
    sources = SourceBook(root)
    raw_fields = store.fields
    fields = list(raw_fields.keys()) if isinstance(raw_fields, dict) else list(raw_fields)
    filter_fields = list(getattr(store, "filter_fields", fields))
    default_group = "cClassTrib" if "cClassTrib" in fields else (fields[0] if fields else "cClassTrib")
    group_choices = [(_FIELD_LABELS.get(name, name), name) for name in fields]
    filter_choices = [(_FIELD_LABELS.get(name, name), name) for name in filter_fields]

    def new_session():
        # Each browser session receives its own provider, context and history.
        secret = os.environ.get("MERIDIONAL_API_KEY") or os.environ.get("OPENAI_API_KEY")
        provider = LocalProvider() if default_local else (OpenAIProvider(secret, model=os.environ.get("MERIDIONAL_MODEL", "gpt-4.1-mini")) if secret else None)
        conversation = Conversation(Engine(store), sources, provider)
        session = _Session(conversation, tempfile.mkdtemp(prefix="meridional-session-"),
                           mode="Modo local limitado — regras, sem IA" if default_local else ("IA · OpenAI · " + os.environ.get("MERIDIONAL_MODEL", "gpt-4.1-mini") if secret else "Chave ausente · configure a IA ou escolha o modo local limitado"))
        _refresh(session)
        return session

    def _refresh(session):
        ctx = session.conversation.context
        try:
            session.analysis = session.conversation.engine.analyze(
                scenario=ctx.get("scenario", "2033"), filters=ctx.get("filters", {}), group_by=ctx.get("group_by", default_group))
            session.records = session.conversation.engine.records(filters=ctx.get("filters", {}))
            session.evidence = session.analysis.get("evidence", [])
        except (ValueError, KeyError, OSError):
            session.analysis = None
            session.records = []
            session.notice = "Erro na leitura ou na cobertura dos dados. Consulte a auditoria; nenhum total parcial é apresentado como total da empresa."

    def _context(session):
        ctx = session.conversation.context
        filters = ctx.get("filters", {})
        label = " · ".join(f"{_FIELD_LABELS.get(k, k)}: {v}" for k, v in filters.items()) or "Todos os registros disponíveis"
        view = (session.analysis or {}).get("hypothetical", session.analysis or {})
        count = view.get("count", len(session.records) if session.records else None)
        return (f"**Recorte ativo:** {html.escape(label)}  \n"
                f"**Cenário:** {html.escape(str(ctx.get('scenario', '2033')))} · "
                f"**Agrupamento:** {html.escape(_FIELD_LABELS.get(ctx.get('group_by'), str(ctx.get('group_by', default_group))))} · "
                f"**Itens no recorte:** {count if count is not None else 'indisponível'}  \n"
                f"{html.escape(str(store.audit.get('coverage_note', 'Equivalência com a referência v5 não comprovada.')))}")

    def _evidence_files(session):
        files = []
        for evidence in session.evidence:
            evidence = _plain(evidence)
            if not isinstance(evidence, dict):
                continue
            name = evidence.get("original_path") or evidence.get("path")
            if not name:
                continue
            path = Path(name).resolve()
            if path.is_file() and path.is_relative_to(root) and str(path) not in files:
                files.append(str(path))
        return files

    def _export(session):
        export_dir = Path(session.directory)
        csv_path = export_dir / "registros_da_analise.csv"
        audit_path = export_dir / "auditoria_e_contexto.json"
        rows = [_plain(row) for row in session.records]
        columns = list(dict.fromkeys(key for row in rows for key in row))
        with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=columns or ["sem_registros"], delimiter=";")
            writer.writeheader()
            for row in rows:
                writer.writerow({key: _safe_csv(value) for key, value in row.items()})
        audit_payload = {
            "contexto": session.conversation.context,
            "auditoria": store.audit, "capacidades": store.capabilities,
            "analise": session.analysis, "fontes_da_resposta": session.evidence,
            "hipoteses_do_usuario": session.conversation.hypotheses,
            "registros_exportados": len(rows),
            "observacao_csv": "Cópia derivada; textos que possam executar fórmulas em planilhas recebem apóstrofo. Originais preservados.",
        }
        audit_path.write_text(json.dumps(_plain(audit_payload), ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        return str(csv_path), str(audit_path)

    def _render(session, busy=False, question=""):
        csv_path, audit_path = _export(session)
        ctx = session.conversation.context
        return (session, session.messages, gr.update(value=question, interactive=not busy),
                gr.update(interactive=not busy), _context(session), _metrics(session.analysis),
                _scenario_table(session.analysis), _chart(session.analysis, True), _chart(session.analysis, False),
                _source_markdown(session.evidence), csv_path, audit_path, _records_table(session.records),
                f"**{session.mode}**" + (f"  \n{session.notice}" if session.notice else ""),
                gr.update(value=ctx.get("scenario", "2033")),
                gr.update(value=ctx.get("group_by", default_group)), _evidence_files(session))

    def initialize(session):
        session = session or new_session()
        return _render(session)

    def ask(question, session):
        session = session or new_session()
        question = (question or "").strip()
        if session.busy or not question:
            yield _render(session, busy=session.busy)
            return
        session.busy = True
        session.notice = "Processando sua pergunta…"
        session.messages.append({"role": "user", "content": question})
        yield _render(session, busy=True)
        try:
            answer = session.conversation.ask(question)
            session.messages.append({"role": "assistant", "content": answer.text})
            if answer.analysis is not None:
                is_financial = "totals" in answer.analysis or "hypothetical" in answer.analysis
                session.analysis = answer.analysis if is_financial else None
                session.records = answer.records or []
            if answer.evidence:
                session.evidence = answer.evidence
            session.notice = ("Falha técnica informada na conversa. Os indicadores anteriores foram preservados."
                              if answer.error else "Resposta concluída. Consulte as fontes e o recorte ativo abaixo.")
            if answer.analysis is not None and session.analysis is None:
                session.notice = "Consulta de classificação: os indicadores financeiros não foram recalculados. Os registros de suporte estão disponíveis para exportação."
        except Exception:
            # Never leak exception strings: an SDK error may contain credentials.
            session.messages.append({"role": "assistant", "content": "Ocorreu um erro técnico ao processar a pergunta. A análise anterior foi preservada. Verifique a configuração da IA e tente novamente; isso não indica falta de informação nos dados."})
            session.notice = "Erro técnico de processamento. Nenhuma resposta de regras foi usada para substituir uma falha da IA."
        finally:
            session.busy = False
        yield _render(session)

    def configure(mode, secret, model, session):
        session = session or new_session()
        model = (model or "gpt-4.1-mini").strip()
        if mode == "Modo local limitado · sem IA":
            session.conversation.provider = LocalProvider()
            session.mode = "Modo local limitado — regras, sem IA"
            session.notice = "Modo escolhido explicitamente. Aceita operações limitadas e não interpreta livremente qualquer pergunta."
        else:
            secret = secret or os.environ.get("MERIDIONAL_API_KEY") or os.environ.get("OPENAI_API_KEY")
            if not secret:
                session.conversation.provider = None
                session.mode = "Chave ausente"
                session.notice = "Configure uma chave OpenAI no campo protegido ou no segredo do Colab. A assinatura do ChatGPT não inclui acesso à API."
            else:
                try:
                    provider = OpenAIProvider(secret, model=model)
                except ValueError:
                    session.notice = "Configuração não aplicada: o nome do modelo é inválido. Confira o campo Modelo OpenAI. A configuração anterior foi preservada."
                else:
                    session.conversation.provider = provider
                    session.mode = "IA · OpenAI · " + model
                    session.notice = "IA configurada nesta sessão. A conexão será validada no próximo envio."
        return session, "**" + session.mode + "**  \n" + session.notice, gr.update(value="")

    def apply_filters(scenario, group, filter_field, filter_value, session):
        session = session or new_session()
        if session.busy:
            return _render(session, busy=True)
        previous = dict(session.conversation.context)
        filters = dict(previous.get("filters", {}))
        if filter_field != "nenhum":
            if filter_field not in filter_fields or not str(filter_value or "").strip():
                session.notice = "Informe um campo disponível e um valor para aplicar o filtro."
                return _render(session)
            filters[filter_field] = str(filter_value).strip()
        try:
            analysis = session.conversation.engine.analyze(scenario=scenario, filters=filters, group_by=group)
            records = session.conversation.engine.records(filters=filters)
        except (ValueError, KeyError, OSError):
            session.notice = "Não foi possível aplicar esse recorte. Confira o valor, o cenário e a cobertura na auditoria. O recorte anterior foi preservado."
            return _render(session)
        session.conversation.context.update({"scenario": scenario, "group_by": group, "filters": filters})
        session.analysis, session.records = analysis, records
        session.evidence = analysis.get("evidence", [])
        session.notice = "Recorte atualizado pelos controles. A próxima pergunta usará esses filtros."
        return _render(session)

    def clear_filters(session):
        session = session or new_session()
        if not session.busy:
            session.conversation.clear_filters()
            _refresh(session)
            session.notice = "Filtros limpos. O cenário foi preservado e o agrupamento voltou à classificação tributária."
        return _render(session, busy=session.busy)

    def reset(session):
        session = session or new_session()
        if not session.busy:
            session.conversation.reset()
            session.messages.clear()
            _refresh(session)
            session.notice = "Nova conversa iniciada. A configuração do provedor foi preservada nesta sessão."
        return _render(session, busy=session.busy)

    theme = gr.themes.Soft(primary_hue="teal", secondary_hue="slate", neutral_hue="slate", radius_size="lg")
    with gr.Blocks(title="Meridional · Inteligência com evidências", theme=theme, css=CSS, analytics_enabled=False) as app:
        state = gr.State(value=None, time_to_live=3600, delete_callback=_cleanup)
        gr.HTML('<div id="hero"><div class="eyebrow">ATACADISTA MERIDIONAL · LABORATÓRIO DE DECISÕES</div><h1>Converse com os dados.<br>Decida com evidências.</h1><p>Explore classificações e cenários tributários em português, com cálculos locais e fontes verificáveis.</p></div>')
        gr.Markdown("**Uso privado:** este app não cria um link público. A IA é opcional e precisa de configuração. Dados e premissas disponíveis delimitam as respostas.", elem_id="privacy-note")
        if store.audit.get("missing_files"):
            gr.Markdown("**Fontes carregadas:** " + store.reference_name + ". **Pendências:** " + ("; ".join(store.audit["missing_files"]) or "consulte a auditoria") + ". A conferência da referência não certifica documentos primários ausentes.")
        with gr.Group(elem_id="conversation-panel"):
            gr.Markdown("### Sua conversa com a Meridional")
            with gr.Row():
                question = gr.Textbox(label="Faça sua pergunta em português", placeholder="Onde tenho o maior ganho tributário em 2033?", lines=2,
                                      scale=6, elem_id="question-input", max_lines=6)
                send = gr.Button("Enviar", variant="primary", scale=1, elem_id="send-button")
            with gr.Row():
                suggestions = [gr.Button(text, size="sm", elem_classes="suggestion") for text in _SUGGESTIONS]
            with gr.Row():
                new_chat = gr.Button("Nova conversa", size="sm", elem_id="new-conversation")
                clear = gr.Button("Limpar filtros", size="sm", elem_id="clear-filters")
                try_local = gr.Button("Experimentar modo local (sem IA)", size="sm", elem_id="try-local")
            status = gr.Markdown("Inicializando sessão…", elem_id="provider-status")
            chat = gr.Chatbot(type="messages", label="Histórico da conversa", height=330, elem_id="chat-history", sanitize_html=True, show_share_button=False,
                              placeholder="As respostas e suas fontes aparecerão aqui. Configure a IA ou experimente explicitamente o modo local limitado.")
        with gr.Accordion("Configurar IA e privacidade", open=False):
            gr.Markdown("**Provedor:** OpenAI. **Modelo padrão:** `gpt-4.1-mini`. A assinatura do ChatGPT é separada da API.\n\n"
                        "No modo IA, o provedor recebe a pergunta, o contexto necessário para interpretá-la e um catálogo de ferramentas. "
                        "Os cálculos e a base integral permanecem no Python local. Veja a documentação do projeto para a política exata do fluxo. "
                        "A chave é mantida somente na sessão ou no segredo do Colab; nunca é exportada. Não use dados sensíveis no texto da pergunta sem autorização.")
            mode = gr.Radio(["IA · OpenAI", "Modo local limitado · sem IA"], value="Modo local limitado · sem IA" if default_local else "IA · OpenAI", label="Modo de conversa")
            with gr.Row():
                api_key = gr.Textbox(type="password", label="Chave da API OpenAI", placeholder="Cole apenas se não estiver configurada no Colab")
                model = gr.Textbox(label="Modelo OpenAI", value=os.environ.get("MERIDIONAL_MODEL", "gpt-4.1-mini"))
            configure_button = gr.Button("Aplicar configuração", variant="secondary")
            gr.Markdown("O modo local é limitado e identificado em todas as sessões. Uma falha de API nunca ativa esse modo automaticamente.")
        context = gr.Markdown("Carregando recorte…", elem_id="active-context")
        with gr.Accordion("Ajustar cenário, agrupamento e filtros", open=False):
            with gr.Row():
                scenario = gr.Dropdown(_SCENARIOS, value="2033", label="Cenário ativo", interactive=True)
                group = gr.Dropdown(group_choices, value=default_group, label="Agrupar contribuições por", interactive=True)
            with gr.Row():
                filter_field = gr.Dropdown([("Sem novo filtro", "nenhum")] + filter_choices, value="nenhum", label="Adicionar filtro", interactive=True)
                filter_value = gr.Textbox(label="Valor do filtro", placeholder="Valor exato; preserve zeros dos códigos")
                apply = gr.Button("Aplicar recorte", variant="secondary")
            gr.Markdown("Somente campos realmente disponíveis aparecem aqui. O filtro é somado aos filtros ativos; use **Limpar filtros** para remover todos.")
        metrics = gr.HTML(_metrics(None))
        gr.Markdown("**Como ler:** ganho positivo é redução do imposto líquido ou ampliação do saldo credor. Crédito não é lucro nem dinheiro recebido. A análise cobre os registros disponíveis, conforme a auditoria.")
        with gr.Tabs():
            with gr.Tab("Cenários e contribuições"):
                comparison = gr.Dataframe(headers=["Cenário", "Débitos das vendas", "Créditos das compras", "Imposto líquido"], interactive=False, label="Comparação do mesmo recorte")
                with gr.Row():
                    positive = gr.Plot(label="Contribuições positivas")
                    negative = gr.Plot(label="Contribuições negativas")
                gr.Markdown("Os gráficos mostram até 10 grupos por sinal para facilitar a leitura. **Cálculos e exportações incluem todos os registros do recorte.** Valores individuais ausentes não são substituídos por zero.")
            with gr.Tab("Fontes e registros"):
                source_display = gr.Markdown("As fontes aparecerão aqui após a análise.")
                original_download = gr.File(label="Abrir os arquivos originais citados", file_count="multiple", interactive=False)
                gr.Markdown("**Prévia de até 25 registros da análise ativa.** O arquivo abaixo contém todos os registros do recorte, sem limitar ao ranking exibido.")
                preview = gr.Dataframe(interactive=False, label="Registros de suporte · prévia", max_height=320)
                csv_download = gr.File(label="Baixar todos os registros da análise · CSV", interactive=False)
                gr.Markdown("O CSV é uma cópia derivada em UTF-8. Importe chave e códigos como **texto** na planilha para manter os zeros. Textos capazes de executar fórmulas são neutralizados; os originais permanecem intactos.")
            with gr.Tab("Auditoria e limitações"):
                gr.Markdown("Verifique cobertura, arquivos faltantes, duplicatas e capacidades antes de usar a análise em uma decisão. Arquivos citados dentro dos materiais não são considerados anexos disponíveis.")
                gr.JSON(value=_plain({"auditoria": store.audit, "capacidades": store.capabilities}), label="Auditoria dos dados carregados", open=False)
                audit_download = gr.File(label="Baixar auditoria, contexto e fontes · JSON", interactive=False)
        gr.Markdown("Meridional · resultados calculados em Python · premissas documentadas · hipóteses separadas da referência")
        outputs = [state, chat, question, send, context, metrics, comparison, positive, negative, source_display,
                   csv_download, audit_download, preview, status, scenario, group, original_download]
        app.load(initialize, inputs=[state], outputs=outputs, api_name=False)
        send.click(ask, inputs=[question, state], outputs=outputs, show_progress="minimal", api_name="perguntar", concurrency_limit=None)
        question.submit(ask, inputs=[question, state], outputs=outputs, show_progress="minimal", api_name=False, concurrency_limit=None)
        for button, suggestion in zip(suggestions, _SUGGESTIONS):
            button.click(lambda text=suggestion: text, outputs=question, api_name=False).then(
                ask, inputs=[question, state], outputs=outputs, show_progress="minimal", api_name=False, concurrency_limit=None)
        configure_button.click(configure, inputs=[mode, api_key, model, state], outputs=[state, status, api_key], api_name=False)
        def enable_local(session):
            updated, text, _ = configure("Modo local limitado · sem IA", "", "gpt-4.1-mini", session)
            return updated, text, gr.update(value="Modo local limitado · sem IA")
        try_local.click(enable_local, inputs=state, outputs=[state, status, mode], api_name=False)
        apply.click(apply_filters, inputs=[scenario, group, filter_field, filter_value, state], outputs=outputs, api_name=False)
        clear.click(clear_filters, inputs=state, outputs=outputs, api_name=False)
        new_chat.click(reset, inputs=state, outputs=outputs, api_name=False)
        chat.clear(reset, inputs=state, outputs=outputs, api_name=False)
    app.queue(max_size=32, default_concurrency_limit=8)
    return app
