"""Importação aditiva. Nunca corrige ou sobrescreve a referência existente."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import tempfile
import zipfile


def import_archive(archive: str | Path, destination: str | Path) -> Path:
    """Preserva o ZIP e extrai em pasta nova após validar todos os membros.

    Aceita dados, não executáveis. O importador não executa validadores ou
    scripts encontrados no pacote. O motor decide se os esquemas são suportados.
    """
    archive, destination = Path(archive), Path(destination)
    if not archive.is_file() or archive.suffix.lower() != ".zip":
        raise ValueError("Selecione um arquivo ZIP existente.")
    destination.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    name = "".join(c if c.isalnum() or c in "-_" else "_" for c in archive.stem)
    target = destination / f"{name}_{digest[:12]}"
    if target.exists():
        raise ValueError("Este pacote já foi importado; nenhum arquivo foi alterado.")
    with zipfile.ZipFile(archive) as z:
        members = z.infolist()
        if len(members) > 20000 or sum(m.file_size for m in members) > 1024**3:
            raise ValueError("Pacote acima do limite: 20 mil arquivos ou 1 GB extraído.")
        seen = set()
        for member in members:
            p = PurePosixPath(member.filename)
            if (p.is_absolute() or ".." in p.parts or "\\" in member.filename
                    or ":" in member.filename or p.as_posix() in seen
                    or stat.S_ISLNK(member.external_attr >> 16)):
                raise ValueError("ZIP contém caminho inseguro, duplicado ou link simbólico.")
            seen.add(p.as_posix())
            if member.file_size > 0 and member.file_size / max(member.compress_size, 1) > 1000:
                raise ValueError("Taxa de compressão do ZIP fora do limite de segurança.")
        staging = Path(tempfile.mkdtemp(prefix=".importando-", dir=destination))
        try:
            z.extractall(staging / "conteudo")
            shutil.copyfile(archive, staging / "pacote_original.zip")
            manifest = {
                "arquivo": archive.name, "sha256_zip": digest,
                "aviso": "Importação preservada; nenhuma correção ou classificação aplicada.",
                "arquivos": {
                    p.relative_to(staging).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in (staging / "conteudo").rglob("*") if p.is_file()
                },
            }
            (staging / "manifesto_importacao.json").write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            staging.rename(target)
        except Exception:
            shutil.rmtree(staging)
            raise
    return target
