"""Teste real de navegador do modo local explícito; não testa API nem Colab.

Inicie python app.py e execute python scripts/testar_interface.py.
Requer playwright e Chromium instalado (opcional --chromium /usr/bin/chromium).
"""
from pathlib import Path
import argparse
import json
import time
from urllib.request import urlopen
from playwright.sync_api import sync_playwright, expect


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', default='http://127.0.0.1:7860')
    parser.add_argument('--chromium', default='/usr/bin/chromium')
    parser.add_argument('--out', type=Path, default=Path('outputs/navegador'))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + 30
    while True:
        try:
            with urlopen(args.url + '/config', timeout=2) as response:
                assert json.load(response).get('components')
            break
        except Exception:
            if time.monotonic() >= deadline:
                raise RuntimeError('O servidor não respondeu à consulta funcional /config. Inicie python app.py.') from None
            time.sleep(.3)
    results = []
    def checked(name):
        results.append({'teste': name, 'resultado': 'passou'})
        print('PASSOU:', name, flush=True)

    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=args.chromium, headless=True, args=['--no-sandbox'])
        context = browser.new_context(viewport={'width': 1440, 'height': 1000})
        page = context.new_page()
        errors = []
        page.on('pageerror', lambda exc: errors.append(str(exc)))
        page.goto(args.url, wait_until='domcontentloaded')
        question = page.locator('#question-input textarea')
        send = page.locator('#send-button')
        question.wait_for(timeout=30000)
        expect(page.locator('#provider-status')).not_to_contain_text('Inicializando', timeout=30000)
        assert question.bounding_box()['y'] < 600
        expect(send).to_be_visible()
        checked('Abrir aplicação e localizar pergunta/Enviar antes dos indicadores')

        def ask(text):
            old = page.locator('#chat-history .message').count()
            question.fill(text)
            send.click()
            expect(question).to_be_enabled(timeout=45000)
            expect(page.locator('#provider-status')).not_to_contain_text('Processando', timeout=45000)
            expect(page.locator('#chat-history')).to_contain_text(text, timeout=45000)
            # Wait for the final callback status rather than a PID/open port.
            expect(page.locator('#provider-status')).to_contain_text(
                'classificação' if 'classificação' in text else 'Falha técnica' if 'chave-ausente-test' in text else 'concluída', timeout=45000)
            return page.locator('#chat-history').inner_text()

        question.fill('Qual o ganho em 2033? chave-ausente-test')
        send.click()
        expect(page.locator('#provider-status')).to_contain_text('Falha técnica', timeout=30000)
        expect(page.locator('#chat-history')).to_contain_text('Chave de API ausente')
        checked('Chave ausente é erro de configuração; sem fallback silencioso')
        page.locator('#try-local').click()
        expect(page.locator('#provider-status')).to_contain_text('Modo local limitado', timeout=30000)

        ask('Analise a classe 000001 em 2033')
        expect(page.locator('#active-context')).to_contain_text('000001')
        expect(page.locator('#active-context')).to_contain_text('2033')
        checked('Digitar/enviar/receber cálculo Python em modo local escolhido')
        ask('E em 2027?')
        expect(page.locator('#active-context')).to_contain_text('000001')
        expect(page.locator('#active-context')).to_contain_text('2027')
        checked('Continuação preserva o filtro da classe')

        ask('O que é CBS segundo os materiais do professor?')
        expect(page.locator('#chat-history')).to_contain_text('página 3')
        expect(page.locator('#active-context')).to_contain_text('000001')
        expect(page.locator('#active-context')).to_contain_text('2027')
        page.get_by_role('tab', name='Fontes e registros', exact=True).click()
        expect(page.get_by_text('Abrir os arquivos originais citados', exact=False)).to_be_visible(timeout=10000)
        expect(page.locator('body')).to_contain_text('enunciado_e_regras.md.pdf')
        expect(page.locator('body')).to_contain_text('página 3')
        checked('Conceito com fonte consultável preserva análise e filtros')

        ask('Quais documentos sustentam essa conclusão?')
        expect(page.locator('#chat-history')).to_contain_text('enunciado_e_regras.md.pdf')
        checked('Pergunta documental recupera a fonte da resposta conceitual anterior')

        # Download through the real Gradio file endpoint, not a filesystem assertion.
        links = page.locator('a[href*="registros_da_analise.csv"]')
        assert links.count() >= 1
        href = links.first.get_attribute('href')
        response = context.request.get(href if href.startswith('http') else args.url + href)
        assert response.status == 200
        assert b'chave' in response.body()[:1000]
        checked('Exportação CSV acessível pelo navegador com registros do recorte')

        other_context = browser.new_context(viewport={'width': 1440, 'height': 1000})
        other = other_context.new_page()
        other.goto(args.url, wait_until='domcontentloaded')
        expect(other.locator('#provider-status')).not_to_contain_text('Inicializando', timeout=30000)
        expect(other.locator('#active-context')).not_to_contain_text('000001')
        expect(other.locator('#provider-status')).to_contain_text('Chave ausente')
        assert 'Analise a classe' not in other.locator('#chat-history').inner_text()
        checked('Duas sessões reais com histórico, filtros e provedor independentes')
        other_context.close()

        page.locator('#clear-filters').click()
        expect(page.locator('#active-context')).to_contain_text('Todos os registros')
        ask('O resultado vem das vendas ou dos créditos nas compras?')
        expect(page.locator('#chat-history')).to_contain_text('Contribuição das vendas')
        expect(page.locator('#chat-history')).to_contain_text('das compras')
        checked('Decomposição em vendas e compras responde a pergunta sugerida')
        ask('Qual ganho em 2033 e o prazo de ressarcimento?')
        expect(page.locator('#chat-history')).to_contain_text('Não sei informar isso com os dados disponíveis.')
        expect(page.locator('#chat-history')).to_contain_text('66.076.701,39')
        checked('Pergunta parcialmente respondível conserva cálculo e informa lacuna')
        ask('Quais fornecedores concentram o aumento dos créditos?')
        expect(page.locator('#chat-history')).to_contain_text('PLASVIDA ARTEFATOS PLASTICOS LTDA')
        expect(page.locator('#chat-history')).to_contain_text('36.178.740,98')
        checked('Ranking por fornecedor usa a base real recebida e os valores da v5')
        ask('Analise o fornecedor PLASVIDA em 2033')
        ask('E em 2027?')
        expect(page.locator('#active-context')).to_contain_text('PLASVIDA ARTEFATOS PLASTICOS LTDA')
        expect(page.locator('#active-context')).to_contain_text('2027')
        expect(page.locator('#chat-history')).to_contain_text('12.014.072,34')
        checked('Fornecedor real preservado na continuação para 2027')
        ask('Quais produtos explicam esse ganho?')
        expect(page.locator('#active-context')).to_contain_text('Produto')
        expect(page.locator('#active-context')).to_contain_text('PLASVIDA')
        checked('Detalhamento por produto preserva fornecedor e cenário')
        page.locator('#clear-filters').click()
        expect(page.locator('#active-context')).to_contain_text('Todos os registros')
        ask('Analise as compras para uso e consumo em 2033')
        expect(page.locator('#active-context')).to_contain_text('960')
        expect(page.locator('#chat-history')).to_contain_text('65.093.390,80')
        checked('Uso e consumo processa os 960 itens reais sem inferir pela ausência de crédito')
        page.locator('#clear-filters').click()
        expect(page.locator('#active-context')).to_contain_text('Todos os registros')
        ask('Por que o produto DIV001 recebeu essa classificação?')
        expect(page.locator('#chat-history')).to_contain_text('NCM 39269090')
        page.get_by_role('tab',name='Fontes e registros',exact=True).click()
        expect(page.locator('body')).to_contain_text('itens_classificados.csv')
        expect(page.locator('body')).to_contain_text('base_itens.csv')
        checked('Classificação de produto tem evidência no CSV final e na base de itens')
        page.locator('#clear-filters').click()
        expect(page.locator('#active-context')).to_contain_text('Todos os registros')
        ask('Qual foi o resultado do futebol?')
        expect(page.locator('#chat-history')).to_contain_text('Essa pergunta está fora do meu escopo.')
        checked('Fora do assunto retorna a mensagem de escopo')

        ask('As compras aumentam 10% em 2033')
        expect(page.locator('#chat-history')).to_contain_text('O aumento se refere')
        ask('Nos preços, mantendo quantidades e mix constantes.')
        expect(page.locator('#chat-history')).to_contain_text('Simulação hipotética do usuário')
        expect(page.locator('body')).to_contain_text('HIPÓTESE DO USUÁRIO')
        checked('Esclarecimento preserva 10% e exibe hipótese separada da referência')
        page.screenshot(path=str(args.out/'conversa-desktop.png'), full_page=True)

        page.locator('#new-conversation').click()
        expect(page.locator('#active-context')).to_contain_text('2033')
        expect(page.locator('#active-context')).to_contain_text('Todos os registros')
        expect(page.locator('#chat-history')).not_to_contain_text('Simulação hipotética do usuário', timeout=30000)
        checked('Nova conversa limpa histórico e filtros')

        page.set_viewport_size({'width':390, 'height':844})
        question.scroll_into_view_if_needed()
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 2')
        expect(question).to_be_visible()
        page.screenshot(path=str(args.out/'interface-mobile.png'),full_page=True)
        checked('Layout mobile sem rolagem horizontal e caixa acessível')
        assert not errors, errors
        checked('Nenhum erro JavaScript não tratado no fluxo')
        context.close(); browser.close()
    report={'tipo':'Navegador Chromium real, servidor Python local, modo local explícito; sem API/Colab',
            'resultados':results,'quantidade':len(results),'erros_js':errors}
    (args.out/'resultado.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':
    main()
