"""Auditoria independente, somente leitura, dos dois novos anexos."""
import csv
from collections import Counter, defaultdict
from decimal import Decimal as D
import hashlib
from io import StringIO
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]
ZERO=D('0.00')


def main():
    orig=ROOT/'data/originais'
    with (orig/'base_itens.csv').open(encoding='utf-8-sig',newline='') as f:
        base=list(csv.DictReader(f,delimiter=';'))
    with (orig/'base_completa_meridional.csv').open(encoding='utf-8-sig',newline='') as f:
        old=list(csv.DictReader(f,delimiter=';'))
    with zipfile.ZipFile(orig/'entrega_meridional_v5.zip') as z:
        final=list(csv.DictReader(StringIO(z.read('Meridional/itens_classificados.csv').decode('utf-8-sig')),delimiter=';'))
        payload=json.loads(z.read('Meridional/simulacao.json'),parse_float=D)
        ledger=list(csv.DictReader(StringIO(z.read('correcoes_aplicadas.csv').decode('utf-8-sig')),delimiter=';'))
    key=lambda r:(r['chave'],str(r['nItem']))
    data={'base_itens':base,'v5_csv':final,'v5_json':payload['itens'],'consolidado_anterior':old}
    key_counts={name:Counter(key(r) for r in rows) for name,rows in data.items()}
    if any(n>1 for counts in key_counts.values() for n in counts.values()):
        raise ValueError('Duplicatas: auditoria não agregou registros nem descartou linhas.')
    universe=set(key_counts['v5_json'])
    joins={name:{'rows':len(rows),'duplicates':0,'missing':len(universe-set(key_counts[name])),'extra':len(set(key_counts[name])-universe)} for name,rows in data.items()}
    if any(j['missing'] or j['extra'] for j in joins.values()):
        raise ValueError('Cobertura divergente; totais não produzidos.')
    b={key(r):r for r in base};o={key(r):r for r in old}
    class_differences=Counter(c for r in final for c in r if r[c]!=o[key(r)].get(c))
    monetary_differences=0
    for r in payload['itens']:
        for s in ('hoje','2027','2033'):
            for field in ('imposto','credito','aliquota_efetiva_pct'):
                a=r[s][field];v=o[key(r)][f'{s}_{field}']
                monetary_differences+=not ((a is None and v=='') or (a is not None and v!='' and D(str(a))==D(v)))
    totals={};rankings={}
    for s in ('hoje','2027','2033'):
        deb=sum((D(str(r[s]['imposto'])) for r in payload['itens'] if r['perspectiva']=='venda'),ZERO)
        cre=sum((D(str(r[s]['credito'])) for r in payload['itens'] if r['perspectiva']=='compra'),ZERO)
        totals[s]={'debitos':str(deb),'creditos':str(cre),'liquido':str(deb-cre)}
    for s in ('2027','2033'):
        rankings[s]={}
        for field in ('produto','fornecedor','destinatario','finalidade'):
            groups=defaultdict(lambda:{'count':0,'sales_effect':ZERO,'purchase_effect':ZERO,'creditos':ZERO})
            for r in payload['itens']:
                row=b[key(r)]
                label={'produto':row['cProd'],
                       'fornecedor':row['emitente_nome'] if r['perspectiva']=='compra' else 'Não se aplica — vendas',
                       'destinatario':row['destinatario_nome'] if r['perspectiva']=='venda' else 'Não se aplica — compras',
                       'finalidade':row['finalidade_compra'] if r['perspectiva']=='compra' else 'Não se aplica — vendas'}[field]
                g=groups[label];g['count']+=1
                if r['perspectiva']=='venda':g['sales_effect']+=D(str(r['hoje']['imposto']))-D(str(r[s]['imposto']))
                else:
                    g['purchase_effect']+=D(str(r[s]['credito']))-D(str(r['hoje']['credito']))
                    g['creditos']+=D(str(r[s]['credito']))
            rows=[{'label':label,**g,'gain':g['sales_effect']+g['purchase_effect']}for label,g in groups.items()]
            rows.sort(key=lambda x:-x['gain'])
            expected=D(totals['hoje']['liquido'])-D(totals[s]['liquido'])
            assert sum((x['gain']for x in rows),ZERO)==expected
            rankings[s][field]=[{k:str(v) if isinstance(v,D)else v for k,v in row.items()} for row in rows]
    report={'origins':{name:hashlib.sha256((orig/name).read_bytes()).hexdigest() for name in ('entrega_meridional_v5.zip','base_itens.csv')},
            'joins':joins,'classification_differences_vs_consolidated':dict(class_differences),
            'monetary_differences_vs_consolidated':monetary_differences,
            'base_perspective_conflicts':sum(r['perspectiva']!=o[key(r)]['perspectiva']for r in base),
            'base_vProd_conflicts':sum(D(r['vProd'])!=D(o[key(r)]['vProd'])for r in base),
            'products':len({r['cProd']for r in base}),'descriptions':len({r['descricao']for r in base}),
            'suppliers':len({r['emitente_id']for r in base if r['perspectiva']=='compra'}),
            'recipients':len({r['destinatario_id']for r in base if r['perspectiva']=='venda'}),
            'use_consumption_rows':sum(r['perspectiva']=='compra'and r['finalidade_compra']=='uso_consumo'for r in base),
            'correction_ledger_rows':len(ledger),'totals':totals,'rankings':rankings,
            'limitations':['DANFEs, cadastros originais e tabelas citadas não foram anexados.','O notebook recebido no ZIP não foi executado.','Conferência aritmética não certifica a acurácia das classificações.']}
    target=ROOT/'docs/evidencias/auditoria-v5.json';target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Auditoria independente gravada:',target)
    print('Cobertura:',joins)
    print('Diferenças de classificação:',dict(class_differences),'monetárias:',monetary_differences)


if __name__=='__main__':main()
