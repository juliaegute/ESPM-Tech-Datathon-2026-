"""python scripts/importar_dados.py arquivo.zip [--destino data/complementares]."""
from pathlib import Path
import argparse
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from meridional.imports import import_archive


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Importa sem alterar a base existente")
    parser.add_argument("arquivo", type=Path)
    parser.add_argument("--destino", type=Path, default=Path("data/complementares"))
    args = parser.parse_args()
    try:
        result = import_archive(args.arquivo, args.destino)
    except (ValueError, OSError) as exc:
        parser.exit(1, f"Importação não realizada: {exc}\n")
    print(f"Preservado em {result}. Reinicie a aplicação para auditar o novo conjunto.")
