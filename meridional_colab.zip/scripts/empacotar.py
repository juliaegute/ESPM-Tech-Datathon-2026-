"""Gera um pacote Colab com fontes, dados e manifesto de integridade."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def build():
    output = ROOT / "dist" / "meridional_colab.zip"
    output.parent.mkdir(exist_ok=True)
    paths = []
    for entry in ("meridional", "scripts", "tests", "docs", "data"):
        paths.extend(p for p in (ROOT / entry).rglob("*")
                     if p.is_file() and "__pycache__" not in p.parts and not any(part.startswith('.') for part in p.relative_to(ROOT).parts))
    paths.extend(ROOT / name for name in (
        "app.py", "README.md", "requirements.txt", "requirements-dev.txt", "Meridional_IA.ipynb",
    ))
    paths = sorted(set(paths))
    manifest = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for p in paths:
            archive.write(p, p.relative_to(ROOT).as_posix())
        archive.writestr("MANIFESTO_PACOTE.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    print(f"Pacote: {output} ({output.stat().st_size:,} bytes; {len(paths)} arquivos com SHA-256)")
    return output


if __name__ == "__main__":
    build()
