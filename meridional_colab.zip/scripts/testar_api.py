"""Teste opt-in real da API. Não usa mocks e não imprime chaves.

Configure MERIDIONAL_API_KEY com segurança e execute:
python scripts/testar_api.py --executar
Este teste transmite as perguntas listadas à OpenAI e pode gerar custo de API.
"""
from pathlib import Path
import argparse
import json
import os
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from meridional.data import DataStore
from meridional.engine import Engine
from meridional.sources import SourceBook
from meridional.conversation import Conversation, OpenAIProvider

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--executar', action='store_true')
    parser.add_argument('--out',type=Path,default=ROOT/'outputs/api-real.json')
    args=parser.parse_args()
    args.out.parent.mkdir(parents=True,exist_ok=True)
    key=os.environ.get('MERIDIONAL_API_KEY') or os.environ.get('OPENAI_API_KEY')
    report={'tipo':'Integração real com OpenAI, sem respostas simuladas',
            'modelo':os.environ.get('MERIDIONAL_MODEL','gpt-4.1-mini'), 'resultados':[]}
    if not args.executar or not key:
        report.update(status='não executado', motivo='Execução não solicitada.' if not args.executar else 'Chave de API ausente; nenhum pedido enviado ao provedor.')
        args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        print(report['motivo'])
        return 2
    conversation=Conversation(Engine(DataStore(ROOT)),SourceBook(ROOT),OpenAIProvider(key,report['modelo']))
    cases=[
        ('Onde tenho o maior ganho tributário em 2033?', {'ranking','analysis'}),
        ('Quais classes trazem as maiores perdas em 2027?', {'ranking','analysis'}),
        ('Analise a classe 000001 em 2033', {'ranking','analysis'}),
        ('E em 2027?', {'ranking','analysis'}),
        ('O que é CBS segundo os materiais?', {'concept'}),
        ('Quais documentos sustentam essa conclusão?', {'documents'}),
        ('Qual é o prazo de ressarcimento dos créditos?', {'missing'}),
        ('Quem ganhou o jogo de futebol?', {'out_of_scope'}),
        ('Saldo tributário negativo significa prejuízo?', {'concept'}),
        ('Onde estão os créditos por fornecedor?', {'analysis','ranking'}),
        ('Qual o efeito das compras para uso e consumo?', {'analysis','ranking'}),
        ('Simule preços das compras +10% em 2033, mantendo quantidades e mix constantes.', {'projection'}),
        ('E se as compras aumentarem 10%?', {'clarify'}),
    ]
    for question, kinds in cases:
        answer=conversation.ask(question)
        passed=answer.error is None and answer.kind in kinds
        if question=='E em 2027?':
            passed=passed and conversation.context['filters'].get('cClassTrib')=='000001' and conversation.context['scenario']=='2027'
        if answer.kind=='concept':
            passed=passed and bool(answer.evidence)
        if answer.kind=='projection':
            passed=passed and bool(answer.analysis.get('reference')) and bool(answer.analysis.get('hypothetical'))
        report['resultados'].append({'pergunta':question,'tipo':answer.kind,'erro':answer.error,'passou':passed,'contexto':dict(conversation.context)})
        print(('PASSOU' if passed else 'FALHOU') + ': ' + question)
    report['status']='passou' if all(r['passou'] for r in report['resultados']) else 'falhou'
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return 0 if report['status']=='passou' else 1


if __name__=='__main__':
    raise SystemExit(main())
